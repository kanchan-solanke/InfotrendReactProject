import { useState } from "react";

import "./scss/style.scss";
import "./App.scss";
import Main from "./Components/Main";

function App() {
  return (
    <>
      <Main />
    </>
  );
}

export default App;
