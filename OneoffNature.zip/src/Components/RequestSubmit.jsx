import React from "react";
import Headers from "./Heading";
import Navbar from "./Navbar";
import tick from "../assets/tick.svg";
import Footer from "./Footer";

export default function RequestSubmit() {
  return (
    <div className="request-submit-wrapper">
      <div className="d-flex justify-content-end bg-white">
        <Headers />
      </div>
      <div className="pt-2 bg-white">
        <Navbar />
      </div>
      <div className="container pt-5 px-5 pb-5">
        <div className="bg-white text-center p-2">
          <div className="d-flex flex-column pt-4">
            <div>
              <img src={tick} alt="" className="pb-4 pt-5" />
            </div>
            <div className="pb-3 text-success fw-500">
            REQUEST SUBMITTED SUCCESSFULLY.....!
            </div>
          </div>
          <div className="pb-4">
            <p className="fw-600">
            Thank you for sending your request to the designer....!
            </p>
            <p className="fw-600">Request ID: 1234567890</p>
          </div>
          <div className="pb-1">
            <p>Your Request is currently being processed.</p>
            <p className="pb-1">
            You will get a confirmation email shortly on your registered email id
            </p>
          </div>
          <div className="text-center pb-5 pt-5">
            <button class="bg-dark btn px-4 py-2 text-white mb-3" type="button">
            UPCYCLE MARKET
            </button>
          </div>
        </div>
      </div>
      <div className="pt-5">
        <Footer/>
      </div>
    </div>
  );
}
