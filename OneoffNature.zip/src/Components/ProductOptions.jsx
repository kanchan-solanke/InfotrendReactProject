import React from "react";

const colors = [
  "#C60021",
  "#5E6075",
  "#FAE596",
  "#84D3EE",
  "#E3E3E3",
  "#33FFFF",
];
const sizes = ["S", "M", "L", "XL", "XXL"];

const ProductOptions = () => {
  return (
    <div className="product-wrapper bg-white pb-3 position-absolute pt-3 text-nowrap">
      <div className="d-flex justify-content-center mb-2">
        <div className="fw-bold me-1">Colors :</div>

        {colors.map((color, index) => (
          <div
            key={index}
            className="rounded-circle border border-dark mx-2"
            style={{
              width: "20px",
              height: "20px",
              backgroundColor: color,
              cursor: "pointer",
              
            }}
          ></div>
        ))}
      </div>
      <div className="d-flex justify-content-center">
        <div className="fw-bold me-1">Sizes:</div>

        {sizes.map((size, index) => (
          <div
            key={index}
            className="d-flex justify-content-center align-items-center border border-dark mx-2"
            style={{
              width: "40px",
              height: "30px",
              cursor: "pointer",
            }}
          >
            {size}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductOptions;
