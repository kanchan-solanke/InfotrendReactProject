import React, { useEffect } from "react";
import redgirl from "../assets/redgirl.png";

export default function CarouselBackground() {
  useEffect(() => {
    const carouselElement = document.getElementById(
      "carouselExampleIndicators"
    );
    const carousel = new bootstrap.Carousel(carouselElement, {
      interval: false,
    });
  }, []);
  return (
    <div className="carousle-background-wrapper">
      <div
        id="carouselExampleIndicators"
        class="carousel slide"
        data-bs-ride="carousel"
      >
        <div class="carousel-indicators rounded-pill">
          <button
            type="button"
            data-bs-target="#carouselExampleIndicators"
            data-bs-slide-to="0"
            class="active"
            aria-current="true"
            aria-label="Slide 1"
          ></button>
          <button
            type="button"
            data-bs-target="#carouselExampleIndicators"
            data-bs-slide-to="1"
            aria-label="Slide 2"
          ></button>
          <button
            type="button"
            data-bs-target="#carouselExampleIndicators"
            data-bs-slide-to="2"
            aria-label="Slide 3"
          ></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active position-relative">
            <img src={redgirl} class="d-block w-100" alt="First slide" />
            <div class="overlay-content text-dark rounded">
              <h3 className="pb-3  fw-bold fs-2">REVITALISE TO RELIVE</h3>
              <p style={{ width: "542px" }} className="pb-5 ">
                ONEOFFNATURE is a digital platform connecting you with some of
                the most innovative emerging sustainable designers to upcycle
                your used garments into a one of a kind piece. By Upcycling not
                only are you giving your clothes a new lease of life and helping
                reduce landfill waste..
              </p>

              <div className=" pb-5">
                <button
                  class="bg-dark btn px-4 py-2 text-white mb-3"
                  type="button"
                >
                  UPCYCLE NOW
                </button>
              </div>
            </div>
          </div>
          <div class="carousel-item active position-relative">
            <img src={redgirl} class="d-block w-100" alt="First slide" />
            <div class="overlay-content text-dark rounded">
              <h3 className="pb-3  fw-bold fs-2">REVITALISE TO RELIVE</h3>
              <p style={{ width: "542px" }} className="pb-5 ">
                ONEOFFNATURE is a digital platform connecting you with some of
                the most innovative emerging sustainable designers to upcycle
                your used garments into a one of a kind piece. By Upcycling not
                only are you giving your clothes a new lease of life and helping
                reduce landfill waste..
              </p>

              <div className=" pb-5">
                <button
                  class="bg-dark btn px-4 py-2 text-white mb-3"
                  type="button"
                >
                  UPCYCLE NOW
                </button>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-item position-relative">
          <img src={redgirl} class="d-block w-100" alt="Third slide" />
          <div class="overlay-content bg-dark text-white p-3 rounded">
            <h3 className="pb-3  fw-bold fs-2">REVITALISE TO RELIVE</h3>
            <p style={{ width: "542px" }} className="pb-5 ">
              ONEOFFNATURE is a digital platform connecting you with some of the
              most innovative emerging sustainable designers to upcycle your
              used garments into a one of a kind piece. By Upcycling not only
              are you giving your clothes a new lease of life and helping reduce
              landfill waste..
            </p>
          </div>
        </div>
      </div>
      <button
        class="carousel-control-prev"
        type="button"
        data-bs-target="#carouselExampleIndicators"
        data-bs-slide="prev"
      >
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button
        class="carousel-control-next"
        type="button"
        data-bs-target="#carouselExampleIndicators"
        data-bs-slide="next"
      >
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>
  );
}
