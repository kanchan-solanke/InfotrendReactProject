import React, { useState } from "react";
import Headers from "./Heading";
import Navbar from "./Navbar";
import Sidebar from "./Sidebar";
import Footer from "./Footer";
import publication from "../assets/publication.png";
import { BsSearch } from "react-icons/bs";
import pp1 from "../assets/pp1.png";
import pp2 from "../assets/pp2.png";
import pp3 from "../assets/pp3.png";
import pp4 from "../assets/pp4.png";
import pp5 from "../assets/pp5.png";
import pp6 from "../assets/pp6.png";
import pp7 from "../assets/pp7.png";
import pp8 from "../assets/pp8.png";
import pp9 from "../assets/pp9.png";
import pp10 from "../assets/pp10.png";
import pp11 from "../assets/pp11.png";
import pp12 from "../assets/pp12.png";

import publication2 from "../assets/publication2.png";
import publication3 from "../assets/publication3.png";
import publication4 from "../assets/publication4.png";
import publication5 from "../assets/publication5.png";
import publication6 from "../assets/publication6.png";
import publication7 from "../assets/publication7.png";
import publication8 from "../assets/publication8.png";
import publication9 from "../assets/publication9.png";
import publication10 from "../assets/publication10.png";
import publication11 from "../assets/publication11.png";

import publication13 from "../assets/publication13.png";

export default function Publications() {
  const [activeLink, setActiveLink] = useState("all");

  const handleClick = (link) => {
    setActiveLink(link);
  };

  return (
    <div className="publication-wrapper">
      <Sidebar />
      <div className="d-flex bg-white justify-content-end">
        <Headers />
      </div>

      <div className="bg-white">
        <Navbar />
      </div>

      <section className="bg-primary px-3 py-3 flex-wraps-upcycle">
        <div className="row">
          <div className="col-12">
            <div className="container mission-inner-wrapper p-0">
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item ps-2">
                    <a
                      href="#"
                      className="text-decoration-none text-secondary fs-8"
                    >
                      HOME
                    </a>
                  </li>
                  <li
                    className="breadcrumb-item active text-dark fw-600"
                    aria-current="page"
                  >
                    PUBLICATIONS
                  </li>
                </ol>
              </nav>
            </div>
          </div>
        </div>
      </section>
      <div className="p-0">
        <section>
          <div className="row">
            <div className="col-12">
              <div className="mission-wrap position-relative">
                <img src={publication} className="mission-img img-fluid" />

                <div className="centered d-flex align-items-center  text-white justify-content-center flex-column our-mission position-absolute px-5 pb-5">
                  <h1 className="text-white fs-42">PUBLICATIONS</h1>
                  <p className="px-5">
                    Lorem ipsum dolor sit amet, consetetur sadipscing elitr,sed
                    <p>
                      diam nonumy eirmod tempor invidunt ut labore et dolore
                      magna
                    </p>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <div className="container pt-5">
          <section>
            <nav className="navbar navbar-expand-md navbar-light bg-light">
              <div className="container-fluid">
                <div className="collapse navbar-collapse" id="publication">
                  <ul className="navbar-nav me-auto">
                    <li className="nav-item">
                      <a
                        className={`nav-link ${
                          activeLink === "all" ? "active" : ""
                        }`}
                        aria-current="page"
                        href="#"
                        onClick={() => handleClick("all")}
                      >
                        All
                      </a>
                    </li>
                    <li className="nav-item">
                      <a
                        className={`nav-link ${
                          activeLink === "featured" ? "active" : ""
                        }`}
                        href="#"
                        onClick={() => handleClick("featured")}
                      >
                        Featured
                      </a>
                    </li>
                    <li className="nav-item">
                      <a
                        className={`nav-link ${
                          activeLink === "highlighted" ? "active" : ""
                        }`}
                        href="#"
                        onClick={() => handleClick("highlighted")}
                      >
                        Highlighted
                      </a>
                    </li>
                    <li className="nav-item">
                      <a
                        className={`nav-link ${
                          activeLink === "most-read" ? "active" : ""
                        }`}
                        href="#"
                        onClick={() => handleClick("most-read")}
                      >
                        Most Read
                      </a>
                    </li>
                    <li className="nav-item">
                      <a
                        className={`nav-link ${
                          activeLink === "editors-choice" ? "active" : ""
                        }`}
                        href="#"
                        onClick={() => handleClick("editors-choice")}
                      >
                        Editors Choice
                      </a>
                    </li>
                  </ul>
                </div>
                <div className="d-flex align-items-center">
                  <button className="btn btn-outline-secondary" type="button">
                    <i className="bi bi-search"></i> Search
                  </button>
                </div>
              </div>
            </nav>
          </section>

          <section className="pb-4">
            <div class="container flex-wraps-upcycle mt-5">
              <div class="row row-cols-1 row-cols-md-3 g-4">
                <div class="col">
                  <div class="card h-100">
                    <img
                      src={publication2}
                      class="card-img-top"
                      alt="Image 1"
                    />
                    <div class="card-body p-4">
                      <h5 class="card-title">Today's Fashion & Trend</h5>
                      <div>
                        <div className="">
                          <p class="card-text">
                            Lorem ipsum dolor sit amet, regerot consetetur
                            sadipscing elitr, seduver diam nonumy rort..
                            <a
                              href="#"
                              className="ms-5 text-decoration-none text-blue"
                            >
                              Read More
                            </a>
                          </p>
                        </div>

                        <div className="d-flex gap-3 align-items-center pt-3">
                          <img src={pp1} className="pt-1 pb-2" />

                          <div>
                            <p>Amelia Wilson</p>
                            <p>22 Jun, 2021</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col">
                  <div class="card h-100">
                    <img
                      src={publication3}
                      class="card-img-top"
                      alt="Image 1"
                    />
                    <div class="card-body p-4">
                      <h5 class="card-title">Today's Fashion & Trend</h5>
                      <div>
                        <div className="">
                          <p class="card-text">
                            Lorem ipsum dolor sit amet, regerot consetetur
                            sadipscing elitr, seduver diam nonumy rort..
                            <a
                              href="#"
                              className="ms-5 text-decoration-none text-blue"
                            >
                              Read More
                            </a>
                          </p>
                        </div>

                        <div className="d-flex gap-3 align-items-center pt-3">
                          <img src={pp2} className="pt-1 pb-2" />

                          <div>
                            <p>Amelia Wilson</p>
                            <p>22 Jun, 2021</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col">
                  <div class="card h-100">
                    <img
                      src={publication3}
                      class="card-img-top"
                      alt="Image 1"
                    />
                    <div class="card-body p-4">
                      <h5 class="card-title">Today's Fashion & Trend</h5>
                      <div>
                        <div className="">
                          <p class="card-text">
                            Lorem ipsum dolor sit amet, regerot consetetur
                            sadipscing elitr, seduver diam nonumy rort..
                            <a
                              href="#"
                              className="ms-5 text-decoration-none text-blue"
                            >
                              Read More
                            </a>
                          </p>
                        </div>

                        <div className="d-flex gap-3 align-items-center pt-3">
                          <img src={pp3} className="pt-1 pb-2" />

                          <div>
                            <p>Amelia Wilson</p>
                            <p>22 Jun, 2021</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col">
                  <div class="card h-100">
                    <img
                      src={publication4}
                      class="card-img-top"
                      alt="Image 1"
                    />
                    <div class="card-body p-4">
                      <h5 class="card-title">Today's Fashion & Trend</h5>
                      <div>
                        <div className="">
                          <p class="card-text">
                            Lorem ipsum dolor sit amet, regerot consetetur
                            sadipscing elitr, seduver diam nonumy rort..
                            <a
                              href="#"
                              className="ms-5 text-decoration-none text-blue"
                            >
                              Read More
                            </a>
                          </p>
                        </div>

                        <div className="d-flex gap-3 align-items-center pt-3">
                          <img src={pp4} className="pt-1 pb-2" />

                          <div>
                            <p>Amelia Wilson</p>
                            <p>22 Jun, 2021</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col">
                  <div class="card h-100">
                    <img
                      src={publication5}
                      class="card-img-top"
                      alt="Image 1"
                    />
                    <div class="card-body p-4">
                      <h5 class="card-title">Today's Fashion & Trend</h5>
                      <div>
                        <div className="">
                          <p class="card-text">
                            Lorem ipsum dolor sit amet, regerot consetetur
                            sadipscing elitr, seduver diam nonumy rort..
                            <a
                              href="#"
                              className="ms-5 text-decoration-none text-blue"
                            >
                              Read More
                            </a>
                          </p>
                        </div>

                        <div className="d-flex gap-3 align-items-center pt-3">
                          <img src={pp5} className="pt-1 pb-2" />

                          <div>
                            <p>Amelia Wilson</p>
                            <p>22 Jun, 2021</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col">
                  <div class="card h-100">
                    <img
                      src={publication6}
                      class="card-img-top"
                      alt="Image 1"
                    />
                    <div class="card-body p-4">
                      <h5 class="card-title">Today's Fashion & Trend</h5>
                      <div>
                        <div className="">
                          <p class="card-text">
                            Lorem ipsum dolor sit amet, regerot consetetur
                            sadipscing elitr, seduver diam nonumy rort..
                            <a
                              href="#"
                              className="ms-5 text-decoration-none text-blue"
                            >
                              Read More
                            </a>
                          </p>
                        </div>

                        <div className="d-flex gap-3 align-items-center pt-3">
                          <img src={pp6} className="pt-1 pb-2" />

                          <div>
                            <p>Amelia Wilson</p>
                            <p>22 Jun, 2021</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col">
                  <div class="card h-100">
                    <img
                      src={publication7}
                      class="card-img-top"
                      alt="Image 1"
                    />
                    <div class="card-body p-4">
                      <h5 class="card-title">Today's Fashion & Trend</h5>
                      <div>
                        <div className="">
                          <p class="card-text">
                            Lorem ipsum dolor sit amet, regerot consetetur
                            sadipscing elitr, seduver diam nonumy rort..
                            <a
                              href="#"
                              className="ms-5 text-decoration-none text-blue"
                            >
                              Read More
                            </a>
                          </p>
                        </div>

                        <div className="d-flex gap-3 align-items-center pt-3">
                          <img src={pp7} className="pt-1 pb-2" />

                          <div>
                            <p>Amelia Wilson</p>
                            <p>22 Jun, 2021</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col">
                  <div class="card h-100">
                    <img
                      src={publication8}
                      class="card-img-top"
                      alt="Image 1"
                    />
                    <div class="card-body p-4">
                      <h5 class="card-title">Today's Fashion & Trend</h5>
                      <div>
                        <div className="">
                          <p class="card-text">
                            Lorem ipsum dolor sit amet, regerot consetetur
                            sadipscing elitr, seduver diam nonumy rort..
                            <a
                              href="#"
                              className="ms-5 text-decoration-none text-blue"
                            >
                              Read More
                            </a>
                          </p>
                        </div>

                        <div className="d-flex gap-3 align-items-center pt-3">
                          <img src={pp8} className="pt-1 pb-2" />

                          <div>
                            <p>Amelia Wilson</p>
                            <p>22 Jun, 2021</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col">
                  <div class="card h-100">
                    <img
                      src={publication9}
                      class="card-img-top"
                      alt="Image 1"
                    />
                    <div class="card-body p-4">
                      <h5 class="card-title">Today's Fashion & Trend</h5>
                      <div>
                        <div className="">
                          <p class="card-text">
                            Lorem ipsum dolor sit amet, regerot consetetur
                            sadipscing elitr, seduver diam nonumy rort..
                            <a
                              href="#"
                              className="ms-5 text-decoration-none text-blue"
                            >
                              Read More
                            </a>
                          </p>
                        </div>

                        <div className="d-flex gap-3 align-items-center pt-3">
                          <img src={pp9} className="pt-1 pb-2" />

                          <div>
                            <p>Amelia Wilson</p>
                            <p>22 Jun, 2021</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col">
                  <div class="card h-100">
                    <img
                      src={publication10}
                      class="card-img-top"
                      alt="Image 1"
                    />
                    <div class="card-body p-4">
                      <h5 class="card-title">Today's Fashion & Trend</h5>
                      <div>
                        <div className="">
                          <p class="card-text">
                            Lorem ipsum dolor sit amet, regerot consetetur
                            sadipscing elitr, seduver diam nonumy rort..
                            <a
                              href="#"
                              className="ms-5 text-decoration-none text-blue"
                            >
                              Read More
                            </a>
                          </p>
                        </div>

                        <div className="d-flex gap-3 align-items-center pt-3">
                          <img src={pp10} className="pt-1 pb-2" />

                          <div>
                            <p>Amelia Wilson</p>
                            <p>22 Jun, 2021</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col">
                  <div class="card h-100">
                    <img
                      src={publication11}
                      class="card-img-top"
                      alt="Image 1"
                    />
                    <div class="card-body p-4">
                      <h5 class="card-title">Today's Fashion & Trend</h5>
                      <div>
                        <div className="">
                          <p class="card-text">
                            Lorem ipsum dolor sit amet, regerot consetetur
                            sadipscing elitr, seduver diam nonumy rort..
                            <a
                              href="#"
                              className="ms-5 text-decoration-none text-blue"
                            >
                              Read More
                            </a>
                          </p>
                        </div>

                        <div className="d-flex gap-3 align-items-center pt-3">
                          <img src={pp11} className="pt-1 pb-2" />

                          <div>
                            <p>Amelia Wilson</p>
                            <p>22 Jun, 2021</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col">
                  <div class="card h-100">
                    <img
                      src={publication11}
                      class="card-img-top"
                      alt="Image 1"
                    />
                    <div class="card-body p-4">
                      <h5 class="card-title">Today's Fashion & Trend</h5>
                      <div>
                        <div className="">
                          <p class="card-text">
                            Lorem ipsum dolor sit amet, regerot consetetur
                            sadipscing elitr, seduver diam nonumy rort..
                            <a
                              href="#"
                              className="ms-5 text-decoration-none text-blue"
                            >
                              Read More
                            </a>
                          </p>
                        </div>

                        <div className="d-flex gap-3 align-items-center pt-3">
                          <img src={pp12} className="pt-1 pb-2" />

                          <div>
                            <p>Amelia Wilson</p>
                            <p>22 Jun, 2021</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <section className="pt-5 pb-5 text-center">
            <button
              type="button"
              class="btn btn-light border border-dark px-4 py-2 text-center"
            >
              VIEW MORE
            </button>
          </section>
        </div>
        <div className="pt-5">
          <Footer />
        </div>
      </div>
    </div>
  );
}
