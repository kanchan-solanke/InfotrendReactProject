import React from "react";
import pound from "../assets/pound.png";
import { FiMinus } from "react-icons/fi";
import BlackButton from "./BlackButton";

export default function PriceTable() {
  return (
    <>
      <div className="price-table-wrapper border-1 border text-center">
        <div className="container ">
          <div className="row">
            <div className="col-12">
              <h5 className="p-2">PRICE DETAILS</h5>
            </div>
            <div className="col-12 pb-1  price-table-inner-wrapper">
              <div className="row border-bottom-light">
                <div className="col-5">
                  <div className="col-6 text-nowrap fs-14">
                    <div className="pb-1 pt-2">Total MRP (1 item)</div>
                    <div className="pb-1 pt-2">Discount on MRP</div>
                    <div className="pb-1 pt-2">Delivery Charges</div>
                  </div>
                </div>
                <div className="col-2"></div>
                <div className="col-5 fs-14">
                  <div className="col-6 text-nowrap">
                    <div className="pb-1 pt-2">
                      <img
                        src={pound}
                        style={{ width: "9px", height: "12px" }}
                      />
                      100.00
                    </div>
                    <div className="pb-1 pt-2 align-items-center d-flex justify-content-center pb-1 pt-2">
                      <div>
                        <FiMinus className="ps-2 text-green" />
                        <img
                          src={pound}
                          style={{ width: "9px", height: "12px" }}
                          className="text-green"
                        />
                      </div>
                      40.00
                    </div>
                    <div className="pb-1 pt-2">Free</div>
                  </div>
                </div>
              </div>
              <div className="row fw-600 border-bottom-light pb-1">
                <div className="col-5 fs-14">
                  <div className="pb-1 pt-2 text-nowrap">Amount Payable</div>
                </div>
                <div className="col-1"></div>
                <div className="col-5 pb-1 pt-2 fs-14">
                  {" "}
                  <img src={pound} style={{ width: "9px", height: "12px" }} />
                  100.00
                </div>
              </div>
              <div className="row d-flex align-items-center">
                <div className="col-5 text-nowrap" style={{ fontSize: "14px" }}>
                  <p> Total Savings on this order</p>
                </div>
                <div className="col-2"></div>
                <div className="col-5">
                  <div className="pb-1 pt-2">
                    <img src={pound} style={{ width: "9px", height: "12px" }} />
                    40.00
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-12 p-0">
                  <p className="text-nowrap fs-14">
                    Shipping & taxes calculated at checkout
                  </p>
                </div>
              </div>
            </div>

            <div className="col-12 pt-2 pb-2">
              <BlackButton buttonText="PROCEED" />
            </div>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-12">
          <div className="form-check">
            <input
              type="checkbox"
              className="form-check-input d-flex align-items-center"
              id="giftCheck"
            />
            <label className="form-check-label fs-14" htmlFor="giftCheck">
              This order contains a gift
            </label>
          </div>
          <p className="fs-14">Add a note to your order.</p>
        </div>
      </div>
    </>
  );
}
