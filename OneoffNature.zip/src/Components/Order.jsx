import React from "react";
import tick from "../assets/tick.svg";
import Headers from "./Heading";
import Navbar from "./Navbar";
import Footer from "./Footer";

export default function Order() {
  return (
    <div className="order-container">
      <div className="d-flex justify-content-end bg-white">
        <Headers />
      </div>
      <div className="pt-2 bg-white">
        <Navbar />
      </div>
      <div className="container pt-5 pb-5 px-5">
        <div className="bg-white text-center p-2">
          <div className="d-flex flex-column pt-4">
            <div>
              <img src={tick} alt="" className="pb-3 pt-5"/>
            </div>
            <div className="pb-3 text-success fw-500">ORDER CONFIRMED.....!</div>
          </div>
          <div className="pb-4">
            <p className="fw-600">Congratulations your order has been placed successfully....!</p>
            <p className="fw-600">Order ID: 1234567890</p>
          </div>
          <div className="pb-1">
            <p>Your Order is currently being proccessed.</p>
            <p className="pb-1">
              You will get a confirmation email shortly on your registered email
              id.
            </p>
          </div>
          <div className="pb-4 text-blue fw-600">View Order Details</div>
          <div className="text-center pb-5">
            <button class="bg-dark btn px-5 py-2 text-white mb-3" type="button">
            SHOP MORE
            </button>
          </div>
        </div>
      </div>

      <div className="pt-5">
        <Footer/>
      </div>
    </div>
  );
}
