import React from "react";

const Heads = ({ title, className }) => {
  return <div className={`cards-heading-wrapper  ${className}`}>{title}</div>;
};

export default Heads;
