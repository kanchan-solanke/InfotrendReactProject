import React from "react";
import sideone from "../assets/sideone.svg";
import sidetwo from "../assets/sidetwo.svg";
import sidethree from "../assets/sidethree.svg";
import sidefour from "../assets/sidefour.svg";
import sidefive from "../assets/sidefive.svg";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
export default function Sidebar() {
  return (
    <div className="position-fixed  top-0 bottom-0 left-0 rounded-end rounded-top sidebar-wrapper sidebar-width  bg-dark-0 d-flex flex-column align-items-center justify-content-center">
      <div className="border-bottom-light">
        <img src={sideone} alt="Side One" className="img-fluid" />
      </div>
      <div className="border-bottom-light">
        <img src={sidetwo} alt="Side Two" className="img-fluid" />
      </div>
      <div className="border-bottom-light">
        {/* <img src={sidethree} alt="Side Three" className="img-fluid" /> */}
        <Link
          className="nav-link text-decoration-none p-0"
          to="/trend"  data-bs-toggle="tooltip"
          data-bs-placement="right"
          title="Fashion Trends"
          style={{ color: "#403449" }}
        >
          <img src={sidethree} alt="Side Three" className="img-fluid w-100" />
        </Link>
      </div>
      <div className="border-bottom-light">
        <img src={sidefour} alt="Side Four" className="img-fluid" />
      </div>
      <div>
        <img src={sidefive} alt="Side Five" className="img-fluid" />
      </div>
    </div>
  );
}
