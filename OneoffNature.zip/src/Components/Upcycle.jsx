import React from "react";
import Navbar from "./Navbar";
import Sidebar from "./Sidebar";
import Footer from "./Footer";
import Headers from "./Heading";
import Heads from "./Heads";
import upcycle1 from "../assets/upcycle1.png";
import upcycle2 from "../assets/upcycle2.png";
import upcycle3 from "../assets/upcycle3.png";
import upcycle4 from "../assets/upcycle4.png";
import upcycle5 from "../assets/upcycle5.png";
import upcycle6 from "../assets/upcycle6.png";
import upcycle7 from "../assets/upcycle7.png";
import { RxCross2 } from "react-icons/rx";
import uflex1 from "../assets/uflex1.png";
import uflex2 from "../assets/uflex2.png";
import uflex3 from "../assets/uflex3.png";
import uflex4 from "../assets/uflex4.png";
import pound from "../assets/pound.png";

export default function Upcycle() {
  return (
    <div className="upcycle-wrapper">
      <div>
        <Sidebar />
        <div className="d-flex bg-white justify-content-end">
          <Headers />
        </div>
        <div className="container-fluid p-0">
          <div className="bg-white">
            <Navbar />
          </div>

          <section className="bg-primary px-3 py-3">
            <div className="row">
              <div className="col-12">
                <div className="container mission-inner-wrapper p-0">
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item ps-2">
                        <a
                          href="#"
                          className="text-decoration-none text-secondary fs-8"
                        >
                          HOME
                        </a>
                      </li>

                      <li
                        className="breadcrumb-item active text-dark fw-600"
                        aria-current="page"
                      >
                        FIND A DESIGNER
                      </li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </section>
          <section>
            <div className="position-relative z-0">
              <div className="blue-background"></div>
              <div>
                <div className="container upcycle-wraps z-4 position-absolute">
                  <Heads title="UPCYCLE BY" className="fs-42 fw-bold pb-3" />

                  <div className="row m-0">
                    <div className="col p-0">
                      <div className="card card-upcycle  p-1">
                        <img
                          src={upcycle1}
                          className="card-img-top"
                          alt="General Alters & Repairs"
                        />
                        <div className="card-body p-1">
                          <p className="card-text text-center fw-500">
                            General Alters & Repairs
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="col p-0">
                      <div className="card card-upcycle  p-1">
                        <img
                          src={upcycle2}
                          className="card-img-top"
                          alt="Reconstruction"
                        />
                        <div className="card-body p-1">
                          <p className="card-text text-center fw-500">
                            Reconstruction
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="col p-0">
                      <div className="card card-upcycle p-1">
                        <img
                          src={upcycle3}
                          className="card-img-top"
                          alt="Embroidery"
                        />
                        <div className="card-body p-1">
                          <p className="card-text text-center fw-500">
                            Embroidery
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="col p-0">
                      <div className="card card-upcycle p-1">
                        <img
                          src={upcycle4}
                          className="card-img-top"
                          alt="Dyes"
                        />
                        <div className="card-body p-1">
                          <p className="card-text text-center fw-500">Dyes</p>
                        </div>
                      </div>
                    </div>
                    <div className="col p-0">
                      <div className="card card-upcycle p-1">
                        <img
                          src={upcycle5}
                          className="card-img-top"
                          alt="Paints"
                        />
                        <div className="card-body p-1">
                          <p className="card-text text-center fw-500">Paints</p>
                        </div>
                      </div>
                    </div>
                    <div className="col p-0">
                      <div className="card card-upcycle p-1">
                        <img
                          src={upcycle6}
                          className="card-img-top"
                          alt="Creative Lining"
                        />
                        <div className="card-body p-1">
                          <p className="card-text text-center fw-500">
                            Creative Lining
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="col p-0">
                      <div className="card card-upcycle p-1">
                        <img
                          src={upcycle7}
                          className="card-img-top"
                          alt="Embeishment"
                        />
                        <div className="card-body p-1">
                          <p className="card-text text-center fw-500">
                            Embeishment
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <div className=" pt-5">
            <section className="container ">
              <div className="container">
                <div className="row">
                  <div className="col-2 bg-white p-3">
                    <div className="d-flex justify-content-between pt-3 pb-3 border-bottom">
                      <div>
                        <p>FILTERS</p>
                      </div>
                      <div>
                        <p className="text-warning fw-500">Clear All</p>
                      </div>
                    </div>
                    <div>
                      <ul>
                        <li className="d-flex gap-2 pt-2 pb-2 border-bottom">
                          <input
                            class="form-check-input border-0 bg-dark"
                            type="checkbox"
                            value=""
                            id="flexCheckChecked"
                            checked
                          />
                          <label className="text-nowrap fs-10 fw-500 align-items-center d-flex justify-content-center">
                            Alter & Repairs
                          </label>
                        </li>
                        <li className="d-flex gap-1 pt-2 pb-2 border-bottom">
                          <input
                            class="form-check-input border-0 bg-dark"
                            type="checkbox"
                            value=""
                            id="flexCheckChecked"
                            checked
                          />
                          <label className="text-nowrap fs-10 fw-500 align-items-center d-flex justify-content-center">
                            Knitting & Crocheting
                          </label>
                        </li>
                        <li className="d-flex gap-2 pt-2 pb-2 border-bottom">
                          <input
                            class="form-check-input border-0 bg-dark"
                            type="checkbox"
                            value=""
                            id="flexCheckChecked"
                            checked
                          />
                          <label className="text-nowrap fs-10 fw-500 align-items-center d-flex justify-content-center">
                            Bags & Accessories
                          </label>
                        </li>
                        <li className="d-flex gap-2 pt-2 pb-2 border-bottom">
                          <input
                            class="form-check-input border-0 bg-dark"
                            type="checkbox"
                            value=""
                            id="flexCheckChecked"
                            checked
                          />
                          <label className="text-nowrap fs-10 fw-500 align-items-center d-flex justify-content-center">
                            Make to Measure
                          </label>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div className="col-10 flex-wraps-upcycle ps-4">
                    <div className="d-flex gap-3 align-items-center justify-content-end pt-3 upcycle-dropdown-wrapper">
                      <div className="fw-500">Sort By :</div>
                      <div>
                        <div class="btn-group">
                          <button
                            class="btn bg-white btn-sm dropdown-toggle border border-1 p-2 fw-500"
                            type="button"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                          >
                            Popularity
                          </button>
                          <ul class="dropdown-menu">...</ul>
                        </div>
                      </div>
                    </div>

                    <div className="d-flex gap-3 ps-3">
                      <div className="d-flex border-wraps justify-content-between align-items-center rounded-pill border border-1 px-3 gap-2">
                        <div className="fs-10 ">Reconstruction</div>
                        <div>
                          <RxCross2 />
                        </div>
                      </div>
                      <div className="d-flex border-wraps justify-content-between align-items-center rounded-pill border border-1 px-3 gap-2">
                        <div className="fs-10">Dyes</div>
                        <div>
                          <RxCross2 />
                        </div>
                      </div>
                      <div className="d-flex border-wraps justify-content-between align-items-center rounded-pill border border-1 px-3 gap-2">
                        <div className="fs-10">Alter & Repairs</div>
                        <div>
                          <RxCross2 />
                        </div>
                      </div>
                      <div className="d-flex border-wraps justify-content-between align-items-center rounded-pill border border-1 px-3 gap-2">
                        <div className="fs-10">Bags & Accessories</div>
                        <div>
                          <RxCross2 />
                        </div>
                      </div>
                    </div>
                    <div className="pt-4 container">
                      <div className="row">
                        <div className="col-4">
                          <img
                            src={uflex1}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-4">
                          <img
                            src={uflex2}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-4">
                          <img
                            src={uflex3}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-4">
                          <img
                            src={uflex1}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-4">
                          <img
                            src={uflex4}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-4">
                          <img
                            src={uflex3}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-4">
                          <img
                            src={uflex1}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-4">
                          <img
                            src={uflex4}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-4">
                          <img
                            src={uflex3}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="d-flex justify-content-center pt-5 pb-5">
                <button
                  type="button"
                  class="btn mb-5 border-2 border px-4 py-2 fw-600"
                >
                  VIEW MORE
                </button>
              </div>
            </section>
          </div>

          <div>
            <Footer />
          </div>
        </div>
      </div>
    </div>
  );
}
