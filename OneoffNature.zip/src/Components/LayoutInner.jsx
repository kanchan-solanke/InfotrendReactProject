import React from "react";
import Headers from "./Heading";
import Navbar from "./Navbar";

export default function LayoutInner({content}) {
  return (
    <div>
      <div className="shopping-cart-wrapper">
        <div className="d-flex justify-content-end bg-white">
          <Headers />
        </div>
        <div className="bg-white">
          <Navbar />
        </div>

        <div className="pt-5 d-flex align-items-center flex-column">
          <div className="custom-inner-container bg-white">

            {content}
          </div>
        </div>
      </div>
    </div>
  );
}
