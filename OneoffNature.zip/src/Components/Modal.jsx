import React from "react";
import modal1 from "../assets/modal1.png";
import modal2 from "../assets/modal2.png";
import modal3 from "../assets/modal3.png";
import modal4 from "../assets/modal4.png";

export default function Modal() {
  const openModal = () => {
    const modal = new window.bootstrap.Modal(
      document.getElementById("exampleModal")
    );
    modal.show();
  };

  return (
    <div>
      <button type="button" className="btn btn-primary" onClick={openModal}>
        Open Modal
      </button>

      <div
        className="modal fade"
        id="exampleModal"
        tabIndex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog custom-modal modal-dialog-centered">
          <div className="modal-content custom-modal-content text-center">
            <div className="modal-header">
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <h5
              className="modal-title fs-4 fw-bold pb-3"
              id="exampleModalLabel"
            >
              REQUEST SERVICE
            </h5>
            <div>
              <p className="fw-bolder fs-5">How it Works</p>
              <p style={{padding:"0px 78px"}} className="pt-3 pb-4">
                Working with a designer consists of the following interactions
                between yourself and your selected designer.
              </p>
            </div>
            <div className="modal-body custom-modal-body p-3 pt-0">
              <div className="text-center">
                <img
                  src={modal1}
                  alt="Choose Designer and Collaborate"
                  className="img-thumbnail mx-auto d-block mb-2"
                />
                <p>Choose and Collaborate</p>
              </div>
              <div className="text-center">
                <img
                  src={modal2}
                  alt="Send Garment"
                  className="img-thumbnail mx-auto d-block mb-2"
                />
                <p>Send Garment</p>
              </div>
              <div className="text-center">
                <img
                  src={modal3}
                  alt="Designer Refashions"
                  className="img-thumbnail mx-auto d-block mb-2"
                />
                <p>Designer Refashions</p>
              </div>
              <div className="text-center">
                <img
                  src={modal4}
                  alt="Receive Garment"
                  className="img-thumbnail mx-auto d-block mb-2"
                />
                <p>Receive Garment</p>
              </div>
            </div>
            <div className="modal-footer d-flex justify-content-center align-items-center">
              <div className="d-flex fs-11">
                <span className="fw-bold">Note :</span>
                <p>You will need a ONEOFFNATURE account to request services</p>
              </div>
              <div className="pb-5">
              <button type="button" className="btn btn-dark py-48">
                CONTINUE TO PROCEED
              </button>
              </div>
             
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
