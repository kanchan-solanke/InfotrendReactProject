import React from "react";
import Headers from "./Heading";
import Navbar from "./Navbar";
import Heads from "./Heads";
import mission from "../assets/mission.png";
import Sidebar from "./Sidebar";
import supply from "../assets/supply.png";
import material from "../assets/material.png";
import conduct from "../assets/conduct.png";
import values from "../assets/values.png";
import brand from "../assets/brand.png";
import store from "../assets/store.png";
import ethical from "../assets/ethical.png";
import design from "../assets/design.png";
import market from "../assets/Marketplace.svg";
import Footer from "./Footer";

export default function Mission() {
  return (
    <div className="mission-wrapper bg-white m-0 p-0">
      <Sidebar />
      <div className="d-flex justify-content-end">
        <Headers />
      </div>
      <div className="container-fluid p-0">
        <Navbar />
        <section className="bg-primary px-3 py-3">
          <div className="row">
            <div className="col-12">
              <div className="container mission-inner-wrapper p-0">
                <nav aria-label="breadcrumb">
                  <ol className="breadcrumb">
                    <li className="breadcrumb-item ps-2">
                      <a
                        href="#"
                        className="text-decoration-none text-secondary fs-8"
                      >
                        HOME
                      </a>
                    </li>
                    <li
                      className="breadcrumb-item active text-dark fw-600"
                      aria-current="page"
                    >
                      ABOUT
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
          </div>
        </section>

        <section>
          <div className="row">
            <div className="col-12">
              <div className="mission-wrap position-relative">
                <img src={mission} className="mission-img img-fluid" />

                <div className="centered d-flex align-items-center justify-content-center flex-column our-mission position-absolute ">
                  <h1>OUR MISSION</h1>
                  <span>
                    Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed
                    diam nonumy eirmod tempor invidunt ut labore et dolore magna
                    aliquyam erat, sed diam voluptua. At vero eos et accusam et
                    justo duo dolores et ea rebum. Stet clita kasd gubergren, no
                    sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem
                    ipsum dolor sit amet, Lorem ipsum dolor sit amet, consetetur
                    sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut
                    labore et dolore magna aliquyam erat, sed diam voluptua. At
                    vero eos et accusam et justo
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>
       
        <div className="container">
          <section>
            <div className="container pt-5">
              <div className="row">
                <div className="col-12">
                  <Heads className="fs-42  fw-bold" title="Our Actions" />
                </div>
              </div>

              <div className="row pt-4">
                <div className="col-12 col-md-7 mb-4 mb-md-0">
                  <div className="p-5 border h-100">
                    <h6 className="fs-4 fw-600 mb-2">SUPPLY CHAIN</h6>
                    <p className="fw-light">
                      Modern Slavery and Human trafficking are known to be some
                      of the worst examples of human rights abuses, and we do
                      not tolerate this in our brands’ supply chains. Our
                      Ethical Trade Code of Conduct underpins our belief in best
                      practice in the supply chain and describes the minimum
                      standards that all our brands and partners must operate
                      to.
                    </p>
                  </div>
                </div>
                <div className="col-12 col-md-5">
                  <img src={supply} className="w-100 img-fluid ps-4" alt="" />
                </div>
              </div>

              <div className="row pt-5">
                <div className="col-12 col-md-5">
                  <img src={material} className="w-100 img-fluid" alt="" />
                </div>
                <div className="col-12 ps-4 col-md-7 mb-4 mb-md-0">
                  <div className="p-5 border h-100 ">
                    <h6 className="fs-4 fw-600 mb-2">MATERIALS</h6>
                    <p className="fw-light">
                      We know that the raw materials used in our brands’
                      products contribute to the overall impact of our business
                      on the environment and so we aim to achieve full
                      traceability of those raw materials. Where possible we use
                      recycled or repurposed materials for our store design and
                      events in an effort to reduce waste.
                    </p>
                  </div>
                </div>
              </div>

              <div className="row pt-5">
                <div className="col-12 col-md-7 mb-4 mb-md-0">
                  <div className="p-5 border h-100">
                    <h6 className="fs-4 fw-600 mb-2">CODE OF CONDUCT</h6>
                    <p className="fw-light">
                      We encourage our brands and partners to work with us and
                      wherever possible to do more than the legal minimum and to
                      push towards continuous improvement in their operations
                      with regards to the key areas of ethical trading,
                      environmental protection and business ethics. We will work
                      together to create a business environment that supports
                      the delivery of our goals by making sure we understand the
                      challenges and opportunities in and by working in a spirit
                      of partnership with our suppliers.
                    </p>
                  </div>
                </div>
                <div className="col-12 col-md-5">
                  <img src={conduct} className="w-100 img-fluid ps-4" alt="" />
                </div>
              </div>

              <div className="row pt-5">
                <div className="col-12 col-md-5">
                  <img src={values} className="w-100 img-fluid" alt="" />
                </div>
                <div className="col-12 ps-4 col-md-7 mb-4 mb-md-0">
                  <div className="p-5 border h-100 ">
                    <h6 className="fs-4 fw-600 mb-2">SHARED VALUES</h6>
                    <p className="fw-light">
                      In cases where the standards are not being met, we will do
                      our best to work towards a positive resolution, but we
                      will not hesitate to terminate those business
                      relationships if it becomes clear that our values are not
                      shared.
                    </p>
                  </div>
                </div>
              </div>

              <div className="row pt-5">
                <div className="col-12 col-md-7 mb-4 mb-md-0">
                  <div className="p-5 border h-100">
                    <h6 className="fs-4 fw-600 mb-2">BRAND CURATION</h6>
                    <p className="fw-light">
                      Our brands and partners are required to align with and
                      support our values as defined in our Ethical Trade code of
                      conduct. We believe that through mutual transparency, we
                      can create a better way of working that inherently
                      delivers governance of and best practice in the key areas
                      of ethical trading, environmental protection and business
                      ethics.
                    </p>
                  </div>
                </div>
                <div className="col-12 col-md-5">
                  <img src={brand} className="w-100 img-fluid ps-4" alt="" />
                </div>
              </div>

              <div className="row pt-5">
                <div className="col-12 col-md-5">
                  <img src={store} className="w-100 img-fluid" alt="" />
                </div>
                <div className="col-12 ps-4 col-md-7 mb-4 mb-md-0">
                  <div className="p-5 border h-100 ">
                    <h6 className="fs-4 fw-600 mb-2">VM & IN STORE</h6>
                    <p className="fw-light">
                      When it comes to our pop-up stores we can proudly say that
                      our props, furniture and window displays are all
                      constructed of recycled or salvaged materials. Re-using
                      and re-purposing old stage sets, mannequins, furniture and
                      props means we are not buying new every time we pop-up and
                      don't need to dispose of it when we move on
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="pt-5">
            <div className="work-container bg-primary">
              <div className="container mt-5 pt-5 pb-5">
                <div>
                  <Heads className="fs-42 fw-600 pb-2" title="HOW WE WORK" />
                  <p className="pb-4">
                    To ensure you know our sustainability and values are shared
                    between us and all of our brands, each one is assigned one
                    or more of our 3 distinct values. Symbols have been created
                    to assign the values of sustainability, ethical practice and
                    social elemetns to each brand, appearing under their 'brand
                    values' on their collection pages.
                  </p>
                </div>
                <div className="row justify-content-center">
                  <div className="col-md-4 mb-4">
                    <div className="card card-custom pb-5 pt-5 px-3 border-0 h-100 rounded">
                      <div
                        className="d-flex justify-content-center align-items-center"
                        style={{ height: "184px" }}
                      >
                        <img
                          src={ethical}
                          className="card-img-top img-fluid"
                          style={{ maxHeight: "184px", maxWidth: "184px" }}
                          alt="..."
                        />
                      </div>
                      <div className="card-body">
                        <h5 className="card-title px-5">
                          Ethical X Sustainable Shop
                        </h5>
                        <p className="card-text">
                          Seamlessly search through ranges of carefully curated
                          sustainable one-of-a-kind handmade garments from some
                          of the brightest emerging ethical x sustainable
                          designers.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-4 mb-4">
                    <div className="card card-custom pb-5 pt-5 px-3 h-100 border-0 rounded">
                      <div
                        className="d-flex justify-content-center align-items-center"
                        style={{ height: "184px" }}
                      >
                        <img
                          src={design}
                          className="card-img-top img-fluid"
                          style={{ maxHeight: "184px", maxWidth: "184px" }}
                          alt="..."
                        />
                      </div>
                      <div className="card-body">
                        <h5 className="card-title px-5">
                          Support Sustainable Designer
                        </h5>
                        <p className="card-text">
                          Supporting emerging ethical x sustainable designers,
                          with comprehensive summaries offer to look critical
                          areas from growing to establishing your brand.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-4 mb-4">
                    <div className="card card-custom pb-5 pt-5 px-3 border-0  h-100 rounded">
                      <div
                        className="d-flex justify-content-center align-items-center"
                        style={{ height: "184px" }}
                      >
                        <img
                          src={market}
                          className="card-img-top img-fluid"
                          style={{ maxHeight: "184px", maxWidth: "184px" }}
                          alt="..."
                        />
                      </div>
                      <div className="card-body">
                        <h5 className="card-title px-5">Upcycle Marketplace</h5>
                        <p className="card-text">
                          Have your unwanted clothes revitalized and reimagined
                          into a made to measure, tailored, one of a kind piece
                          by one of our designer.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>

        <Footer />
      </div>
    </div>
  );
}
