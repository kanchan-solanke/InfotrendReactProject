import React from "react";
import PriceDetails from "./PriceDetails";
import PriceTable from "./PriceTable";
import Headers from "./Heading";
import Navbar from "./Navbar";
import womenBlack from "../assets/womenBlack.png";
import pound from "../assets/pound.png";

export default function ShoppingCart() {
  return (
    <div className="shopping-cart-wrapper">
      <div className="d-flex justify-content-end bg-white">
        <Headers />
      </div>
      <div className="bg-white">
        <Navbar />
      </div>

      <div className="pt-5 d-flex align-items-center flex-column">
        <div className="bg-white px-sm-1 py-sm-1 px-md-3 py-md-4">
          <div>
            <p className="fw-bold pb-2 border-bottom border-light">
              My Shopping Cart (1 Item)
            </p>
          </div>
          <div className="border border-1">
            <div className="row">
              <div className="col-8 pe-md-2">
               
                  <div className="row">
                    <div className="col-9">
                  
                      <div className="d-flex flex-column gap-3 p-4">
                        <div className="d-flex gap-4">
                          <img
                            src={womenBlack}
                            alt="Product"
                            className="img-fluid"
                          />
                          <div>
                            <p className="fw-bold mb-0">
                              Women Black Solid Styled B...
                            </p>
                            <p className="text-secondary mb-0">SASSAFRAS</p>
                            <p className="text-wrap">
                              Lorem ipsum dolor sit amet, consetetur...
                            </p>
                            <p className="text-wrap">
                              Lorem ipsum dolor sit amet, consetetur...
                            </p>

                            <div className="row gx-3">
                              <div className="col-sm-6 col-md-6">
                                <div className="input-group border-1 border">
                                  <label className="input-group-text">
                                    Size:
                                  </label>
                                  <select
                                    id="sizes"
                                    name="sizes"
                                    className="form-select border-0"
                                  >
                                    <option value="s">S</option>
                                    <option value="m">M</option>
                                    <option value="l">L</option>
                                    <option value="xl">XL</option>
                                  </select>
                                </div>
                              </div>
                              <div className="col-sm-6 col-md-6">
                                <div className="input-group border-1 border">
                                  <label className="input-group-text">
                                    Qty:
                                  </label>
                                  <select
                                    id="quantity"
                                    name="quantity"
                                    className="form-select border-0"
                                  >
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                  </select>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-3">
                      <div className="d-flex justify-content-end p-4">
                        <div>
                          <img src={pound} alt="Currency" />
                        </div>
                        <div>60.00</div>
                      </div>
                      <div className="d-flex justify-content-end">
                        <div>
                          <img src={pound} alt="Currency" />
                        </div>
                        <div>60.00 (40% Off)</div>
                      </div>
                    </div>
                  </div>
                
              </div>
              <div className="col-4">
                <PriceTable />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
