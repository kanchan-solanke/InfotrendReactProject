import React from "react";
import Navbar from "./Navbar";
import Headers from "./Heading";

export default function PriceDetails() {
  return (
    <div className="price-wrapper">
      <div className="d-flex justify-content-end bg-white">
        <Headers />
      </div>
      <div className="pt-2 bg-white">
        <Navbar />
      </div>
      <div className="container  pt-5">
        <div className="row">
          <div className="col-12">
            <div className="border border-2 pt-4 p-5 bg-white ">
              <div className=" pb-5 row">
                <div className="row">
                  <div className="col-7 p-0">
                    <div className="shipping-wrapper">
                      <div className="row d-flex charges-wrapper">
                        <div className="container">
                          <div className="shipping-heading-wrapper">
                            <span>SHIPPING ADDRESS</span>
                          </div>
                          <div>
                            <div className="row contact-details">
                              <span>Contact Details</span>
                            </div>
                            <div className="row">
                              <div className="col-md-6">
                                <form className="">
                                  <div className="">
                                    <label htmlFor="FirstName" className="form">
                                      First Name
                                    </label>
                                    <input
                                      type="FirstName"
                                      className="form-control email-wrap"
                                      id="FirstName"
                                      placeholder="Enter First Name"
                                    />
                                  </div>
                                </form>
                              </div>
                              <div className="col-md-6">
                                {" "}
                                <div className="">
                                  <label htmlFor="LastName" className="form">
                                    Last Name{" "}
                                  </label>
                                  <input
                                    type="LastName"
                                    className="form-control email-wrap"
                                    id="LastName"
                                    placeholder="Enter Last Name"
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="row">
                              <div className="col-md-12">
                                <label
                                  htmlFor="MobileNumber"
                                  className="form mobile-wrap"
                                >
                                  Mobile Number
                                </label>
                                <input
                                  type="MobileNumber"
                                  className="form-control email-wrap"
                                  id="MobileNumber"
                                  placeholder="Enter Mobile Number"
                                />
                              </div>
                            </div>
                            <div className="row">
                              <div className="col-md-12 email-id">
                                <label
                                  htmlFor="EmailId"
                                  className="form emailid-wrap"
                                >
                                  Email Id
                                </label>
                                <input
                                  type="Email Id"
                                  className="form-control email-wraps"
                                  id="Email Id"
                                  placeholder="Enter Email Id"
                                />
                              </div>
                            </div>
                          </div>
                          <div></div>
                        </div>
                        <div className="col-md-1"></div>
                        
                      </div>
                      <div className="row contact-detail">
                        <span>Address</span>
                      </div>
                      <div className="col-md-7">
                        <div className="col-md-12">
                          <label
                            htmlFor="StreetAddress"
                            className="form mobile-wraps"
                          >
                            Street Address
                          </label>
                          <input
                            type="StreetAddress"
                            className="form-control email-wrap"
                            id="StreetAddress"
                            placeholder="Enter the Street Address"
                          />
                        </div>
                        <div className="row">
                          <div className="col-md-6">
                            <label
                              htmlFor="Country"
                              className="form mobile-wrap"
                            >
                              Country
                            </label>
                            <ul class="navbar-nav">
                              <li class="nav-item dropdown">
                                <a
                                  class="nav-link select dropdown-toggle d-flex justify-content-between align-items-center"
                                  href="#"
                                  id="navbarDarkDropdownMenuLink"
                                  role="button"
                                  data-bs-toggle="dropdown"
                                  aria-expanded="false"
                                >
                                  Select Country
                                </a>
                                <ul
                                  class="dropdown-menu dropdown-menu-dark"
                                  aria-labelledby="navbarDarkDropdownMenuLink"
                                >
                                  <li>
                                    <a class="dropdown-item" href="#">
                                      Action
                                    </a>
                                  </li>
                                  <li>
                                    <a class="dropdown-item" href="#">
                                      Another action
                                    </a>
                                  </li>
                                  <li>
                                    <a class="dropdown-item" href="#">
                                      Something else here
                                    </a>
                                  </li>
                                </ul>
                              </li>
                            </ul>
                          </div>
                          <div className="col-md-6">
                            <label
                              htmlFor="State/Province"
                              className="form mobile-wrap"
                            >
                              State/Province
                            </label>
                            <ul class="navbar-nav">
                              <li class="nav-item dropdown">
                                <a
                                  class="nav-link select dropdown-toggle d-flex justify-content-between align-items-center"
                                  href="#"
                                  id="navbarDarkDropdownMenuLink"
                                  role="button"
                                  data-bs-toggle="dropdown"
                                  aria-expanded="false"
                                >
                                  Select State/Province
                                </a>
                                <ul
                                  class="dropdown-menu dropdown-menu-dark"
                                  aria-labelledby="navbarDarkDropdownMenuLink"
                                >
                                  <li>
                                    <a class="dropdown-item" href="#">
                                      Action
                                    </a>
                                  </li>
                                  <li>
                                    <a class="dropdown-item" href="#">
                                      Another action
                                    </a>
                                  </li>
                                  <li>
                                    <a class="dropdown-item" href="#">
                                      Something else here
                                    </a>
                                  </li>
                                </ul>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-md-6">
                            <label htmlFor="City" className="form mobile-wrap">
                              City
                            </label>
                            <input
                              type="City"
                              className="form-control email-wrap"
                              id="City"
                              placeholder="Enter City"
                            />
                          </div>
                          <div className="col-md-6">
                            <label
                              htmlFor="Postcode"
                              className="form mobile-wrap"
                            >
                              Postcode
                            </label>
                            <input
                              type="Postcode"
                              className="form-control email-wrap"
                              id="Postcode"
                              placeholder="Enter Postcode"
                            />
                          </div>

                          <div className="form-check container set">
                            <input
                              type="checkbox"
                              className="form-check-input d-flex align-items-center"
                            />
                            <label
                              className="form-check-label default pb-1"
                              htmlFor="giftCheck"
                            >
                              Set it as my default address
                            </label>
                          </div>
                        </div>
                      </div>
                      <div className="save-continue d-flex justify-content-center align-items-center">
                        <button type="button" class="btn btn-dark">
                          SAVE AND CONTINUE
                        </button>
                      </div>
                    </div>
                  </div>
                  <div className="col-5">dklndlkwd</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
