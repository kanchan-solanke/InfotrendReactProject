import React from "react";
import Sidebar from "./Sidebar";
import Headers from "./Heading";
import Footer from "./Footer";
import Heads from "./Heads";
import Navbar from "./Navbar";
import feature1 from "../assets/feature1.png";
import feature5 from "../assets/feature5.png";
import feature3 from "../assets/feature3.png";
import feature4 from "../assets/feature4.png";
import { BsHeart } from "react-icons/bs";
import pound from "../assets/pound.png";
import pre from "../assets/pre.png";
import next from "../assets/next.png";
function Layout() {
  const images = [
    { component: <feature1 />, text: "Text for Image 1" },
    { component: <feature5 />, text: "Text for Image 2" },
    { component: <feature3 />, text: "Text for Image 3" },
    { component: <feature4 />, text: "Text for Image 4" },
  ];
  return (
    <div className="layout">
      <aside>
        <Sidebar />
      </aside>
      <main>
        <div className="d-flex justify-content-end">
          <Headers />
        </div>
        <section className="custom-container">
          <Navbar />

          <section>
            <div style={{ height: "636px" }} />
          </section>

          <section>
            <div className="carousel-container-feature-wrapper position-relative z-0 ">
              <div className="blue-bg position-absolute z-4  "></div>
              <div className="custom-container">
                <div className="d-flex justify-content-between">
                <div>
                  <Heads title="FEATURED" className="fw-bold" />
                </div>

                <div>
                  <button
                    type="button"
                    className="btn btn-light px-4 py-2 border border-2 text-dark position-absolute z-4"
                  >
                    EXPLORE ALL
                  </button>
                </div>
                </div>
              </div>
              <div className="carousel-container-feature-wrapper position-relative z-0 ">
            <div className="blue-bg position-absolute z-4"></div>
            <div className="custom-container">
              <div className="d-flex justify-content-between">
                <div>
                  <Heads title="FEATURED" className="fw-bold fs-1" />
                </div>

                <div>
                  <button
                    type="button"
                    className="btn btn-light px-4 py-2 border border-2 text-dark position-absolute z-4"
                  >
                    EXPLORE ALL
                  </button>
                </div>
              </div>
            </div>
            <div className="carousel-feature-wrap z-4">
              <div className="d-flex align-items-center justify-content-between position-absolute z-4"></div>
              <div className="home-carousel">
                <div className="col-md-12 text-center carousel-wrap w-100">
                  <div className="d-flex justify-content-center gap-4 wrapper-carousel w-100 pt-4">
                    <div
                      id="myCarousel"
                      className="carousel slide"
                      data-bs-pause="hover"
                      data-interval="false"
                    >
                      <div className="carousel-inner d-flex gap-4 wrapper-carousel w-100">
                        {images.map((src, index) => (
                          <div
                            key={index}
                            className={`carousel-item ${
                              index === 0 ? "active" : ""
                            }`}
                          >
                           <div className="row">
                                <div className="col-3">
                                  <img
                                    src={feature3}
                                    className="d-block img-responsive"
                                    alt={`Slide ${index + 1}`}
                                  />
                                  <div className="text-start">
                                    <div className="d-flex justify-content-between align-items-center flex-text">
                                      <div className="lorem-wrap fw-bold">
                                        Green Printed Maxi Dress
                                      </div>
                                      <div>
                                        <BsHeart />
                                      </div>
                                    </div>

                                    <div className="grace-wrap">SASSAFRAS</div>
                                    <div className="d-flex gap-3">
                                      <div className="fw-bold">
                                        <img src={pound} />
                                        40.00
                                      </div>
                                      <div className="text-decoration-line-through">
                                        <img src={pound} />
                                        80.00
                                      </div>
                                      <div className="off-wrap">(50% Off)</div>
                                    </div>
                                  </div>
                                </div>
                                <div className="col-3">
                                  <img
                                    src={feature3}
                                    className="d-block img-responsive"
                                    alt={`Slide ${index + 1}`}
                                  />
                                  <div className="text-start">
                                    <div className="d-flex justify-content-between align-items-center flex-text">
                                      <div className="lorem-wrap fw-bold">
                                        Polka Dot Printed Two-Piece
                                      </div>
                                      <div>
                                        <BsHeart />
                                      </div>
                                    </div>

                                    <div className="grace-wrap">Berrylush</div>
                                    <div className="d-flex gap-3">
                                      <div className="fw-bold">
                                        <img src={pound} />
                                        40.00
                                      </div>
                                      <div className="text-decoration-line-through">
                                        <img src={pound} />
                                        80.00
                                      </div>
                                      <div className="off-wrap">(50% Off)</div>
                                    </div>
                                  </div>
                                </div>
                                <div className="col-3">
                                  <img
                                    src={feature3}
                                    className="d-block  img-responsive"
                                    alt={`Slide ${index + 1}`}
                                  />
                                  <div className="text-start">
                                    <div className="d-flex justify-content-between align-items-center flex-text">
                                      <div className="lorem-wrap fw-bold">
                                        Lorem Ipsum
                                      </div>
                                      <div>
                                        <BsHeart />
                                      </div>
                                    </div>

                                    <div className="grace-wrap">
                                      GRACE KARIN
                                    </div>
                                    <div className="d-flex gap-3">
                                      <div className="fw-bold">
                                        <img src={pound} />
                                        40.00
                                      </div>
                                      <div className="text-decoration-line-through">
                                        <img src={pound} />
                                        80.00
                                      </div>
                                      <div className="off-wrap">(50% Off)</div>
                                    </div>
                                  </div>
                                </div>
                                <div className="col-3">
                                  <img
                                    src={feature3}
                                    className="d-block img-responsive"
                                    alt={`Slide ${index + 1}`}
                                  />
                                  <div className="text-start">
                                    <div className="d-flex justify-content-between align-items-center flex-text">
                                      <div className="lorem-wrap fw-bold text-nowrap">
                                        Drop wei Light weight dress
                                      </div>
                                      <div>
                                        <BsHeart />
                                      </div>
                                    </div>

                                    <div className="grace-wrap">
                                      {" "}
                                      ModaRapido
                                    </div>
                                    <div className="d-flex gap-3">
                                      <div className="fw-bold">
                                        <img src={pound} />
                                        40.00
                                      </div>
                                      <div className="text-decoration-line-through">
                                        <img src={pound} />
                                        80.00
                                      </div>
                                      <div className="off-wrap">(50% Off)</div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                          </div>
                        ))}
                      </div>
                      <button
                        className="carousel-control-prev"
                        type="button"
                        data-bs-target="#myCarousel"
                        data-bs-slide="prev"
                      >
                        {/* Previous control */}
                      </button>
                      <button
                        className="carousel-control-next"
                        type="button"
                        data-bs-target="#myCarousel"
                        data-bs-slide="next"
                      >
                        {/* Next control */}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
            </div>
          </section>
        </section>
      </main>
    </div>
  );
}

export default Layout;
