import React from "react";
import Headers from "./Heading";
import Navbar from "./Navbar";
import Sidebar from "./Sidebar";
import fashion1 from "../assets/fashion1.png";
import fashion2 from "../assets/fashion2.png";
import fashion3 from "../assets/fashion3.png";
import fashion4 from "../assets/fashion3.png";
import public1 from "../assets/public1.png";
import public2 from "../assets/public2.png";
import public3 from "../assets/public3.png";
import public4 from "../assets/public4.png";
import { SlCalender } from "react-icons/sl";
import Footer from "./Footer";

import { BsSearch } from "react-icons/bs";
import BlackButton from "./BlackButton";

export default function FashionTrend() {
  return (
    <>
      <Sidebar />

      <div className="fashion-trend-wrapper">
        <div className="d-flex bg-white justify-content-end">
          <Headers />
        </div>
        <div className="bg-white">
          <Navbar />
        </div>
        <section className="bg-primary px-3 pt-3">
          <div className="row">
            <div className="col-12">
              <div className="container mission-inner-wrapper">
                <nav aria-label="breadcrumb">
                  <ol className="breadcrumb">
                    <li className="breadcrumb-item ">
                      <a
                        href="#"
                        className="text-decoration-none text-secondary fs-8"
                      >
                        HOME
                      </a>
                    </li>
                    <li className="breadcrumb-item">
                      <a
                        href="#"
                        className="text-decoration-none text-secondary fs-8 text-capitalize	"
                      >
                        PUBLICATIONS
                      </a>
                    </li>
                    <li
                      className="breadcrumb-item active text-dark fw-600"
                      aria-current="page"
                    >
                      TODAY'S FASHION & TREND
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
          </div>
        </section>
        <div className="pt-4  bg-white">
          <div className="container">
            <div className="row">
              <div className="col-8">
                <section>
                  <div>
                    <img src={fashion1} className="img-fluid"/>
                  </div>

                  <div className="pt-4">
                    <div className="d-flex justify-content-between align-items-center">
                      <h3 className="fs-2 fw-600 pb-3">
                        TODAY'S FASHION & TREND
                      </h3>
                      <div className="trends-icon d-flex gap-2 pb-3">
                        <img src={fashion3} />
                        <img src={fashion2} />
                      </div>
                    </div>

                    <p className="pb-4">
                      Joshua Maraschin is a London-based Brazilian designer who
                      has launched his eponymous brand at London Fashion Week,
                      in February 2020.
                    </p>
                    <p className="pb-4">
                      Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
                      sed diam nonumy eirmod tempor invidunt ut vddt labore et
                      dolore magna aliquyam erat, sed diam voluptua. At vero eos
                      et accusam et justo duo dolores et ea rebum. Stet clita
                      kasd gubergren, no sea takimata sanctus est Lorem ipsum
                      dolor sit amet. Lorem ipsum dolor sit amet, consetetur
                      sadipscing elitr, sed diam nonumy eirmod tempor invidunt
                      ut labore et dolore ht magna aliquyam erat, sed diam
                      voluptua. At vero eos et accusam et justo duo dolores et
                      ea rebum. Stet clita kasd gubergren, no sea takimata
                      sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor
                      sit amet, consetetur sadipscing elitr, sed diam nonumy
                      eirmod tempor invidunt ut vfgty labore et dolore magna
                      aliquyam erat, sed diam voluptua. At vero eos et accusam
                      et justo duo dolores et ea rebum. Stet clita kasd
                    </p>
                    <p className="pb-5">
                      Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
                      sed diam nonumy eirmod tempor invidunt ut labore et dolore
                      magna aliquyam erat, sed diam voluptua. At vero eos et
                      accusam et justo duo dolores sum dolor sit amet. Lorem
                      ipsum dolor sit amet, consetetur sadipscing elitr, sed
                      diam nonumy eirmod tempor invidunt ut vfgty labore et
                      dolore magna et ea rebum. Stet clita kasd
                    </p>
                  </div>

                  <div className="d-flex gap-2 align-items-center justify-content-end pb-5">
                    <div>
                      <img src={fashion4} />
                    </div>
                    <div>
                      <p>Amelia Wilson</p>
                      <p>22 Jun, 2021</p>
                    </div>
                  </div>
                </section>
              </div>
              <div className="col-4">
                <div className="px-5">
                  <div class="container search-trend-container mt-5 ">
                    <div
                      class="search-breadcrumb  position-relative
    "
                    >
                      <span class="search-icon  position-absolute">
                        <BsSearch />
                      </span>
                      <input
                        type="text"
                        class="form-control rounded-pill py-2"
                        placeholder="Search Post Here"
                      />
                    </div>
                  </div>

                  <div className="container pt-4">
                    <h3 className="fw-600 fs-16 pb-3 border-bottom-light">
                      CATEGORIES
                    </h3>
                    <ul className="border-bottom-light">
                      <li className="border-bottom-light pt-2 pb-2">All</li>
                      <li className="border-bottom-light pt-2 pb-2">
                        Featured
                      </li>
                      <li className="border-bottom-light pt-2 pb-2">
                        Highlighted
                      </li>
                      <li className="border-bottom-light pt-2 pb-2">
                        Most Read
                      </li>
                      <li className=" pt-2 pb-2">Editors Choice</li>
                    </ul>
                  </div>

                  <div className="container pt-4">
                    <h3 className="fw-600 fs-16 pb-2 border-bottom-light">
                      RELATED POST
                    </h3>
                    <ul className="border-bottom-light">
                      <li className="border-bottom-light pt-2 pb-2">
                        <div>
                          <p>Today's Fashion & Trend</p>
                          <img src={public1} className="pt-1 pb-2" />
                          <div className="d-flex gap-2">
                            <SlCalender />

                            <p>22 Jun 2021</p>
                            <p>By: John Wilson</p>
                          </div>
                        </div>
                      </li>
                      <li className="border-bottom-light pt-2 pb-2">
                        <div>
                          <p>Today's Fashion & Trend</p>
                          <img src={public2} className="pt-1 pb-2" />
                          <div className="d-flex gap-2">
                            <SlCalender />

                            <p>22 Jun 2021</p>
                            <p>By: John Wilson</p>
                          </div>
                        </div>
                      </li>
                      <li className="border-bottom-light pt-2 pb-2">
                        <div>
                          <p>Today's Fashion & Trend</p>
                          <img src={public3} className="pt-1 pb-2" />
                          <div className="d-flex gap-2">
                            <SlCalender />

                            <p>22 Jun 2021</p>
                            <p>By: John Wilson</p>
                          </div>
                        </div>
                      </li>
                      <li className="border-bottom-light pt-2">
                        <div>
                          <p>Today's Fashion & Trend</p>
                          <img src={public4} className="pt-1 pb-2" />
                          <div className="d-flex gap-2">
                            <SlCalender />

                            <p>22 Jun 2021</p>
                            <p>By: John Wilson</p>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>

                <div></div>
              </div>
            </div>

            <div className="work-container bg-primary pt-5 pb-5">
              <div className="container">
                <h3 className="fs-32 text-center text-secondary fw-500">
                  KEEP IN TOUCH
                </h3>

                <div class="mt-3">
                  <form className="form-container flex-wraps-upcycle">
                    <div class="row mb-3">
                      <div class="col-md-6">
                        <label for="firstName" class="form-label m-0 pb-1">
                          First Name
                        </label>
                        <input
                          type="text"
                          class="form-control p-2"
                          id="firstName"
                          placeholder="First Name"
                        />
                      </div>
                      <div class="col-md-6">
                        <label for="lastName" class="form-label m-0 pb-1">
                          Last Name
                        </label>
                        <input
                          type="text"
                          class="form-control p-2"
                          id="lastName"
                          placeholder="Last Name"
                        />
                      </div>
                    </div>

                    <div class="row mb-3">
                      <div class="col-12">
                        <label for="mobileNumber" class="form-label m-0 pb-1">
                          Mobile Number
                        </label>
                        <input
                          type="tel"
                          class="form-control p-2"
                          id="mobileNumber"
                          placeholder="Mobile Number"
                        />
                      </div>
                    </div>

                    <div class="row mb-3">
                      <div class="col-12">
                        <label for="email" class="form-label m-0 pb-1">
                          Email ID
                        </label>
                        <input
                          type="email"
                          class="form-control p-2"
                          id="email"
                          placeholder="Email ID"
                        />
                      </div>
                    </div>

                    <div class="row mb-3">
                      <div class="col-12">
                        <label for="comments" class="form-label m-0 pb-1">
                          Comments
                        </label>
                        <textarea
                          class="form-control p-2"
                          id="comments"
                          rows="3"
                          placeholder="Enter your comments"
                        ></textarea>
                      </div>
                    </div>

                    <div class="row mb-3 pt-3 text-center">
                      <div class="col-12">
                        <BlackButton buttonText="POST COMMENT" />
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    </>
  );
}
