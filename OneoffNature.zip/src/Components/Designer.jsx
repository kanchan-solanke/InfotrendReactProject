import React from "react";
import Navbar from "./Navbar";
import Sidebar from "./Sidebar";
import Footer from "./Footer";
import Headers from "./Heading";
import design1 from "../assets/design1.png";
import Heads from "./Heads";
import { MdOutlineEmail } from "react-icons/md";
import { FaInstagram } from "react-icons/fa6";
import { GoLocation } from "react-icons/go";
import designer1 from "../assets/designer1.png";
import designer2 from "../assets/designer2.png";
import designer3 from "../assets/designer3.png";
import designer4 from "../assets/designer4.png";
import designer5 from "../assets/designer5.png";
import designer6 from "../assets/designer6.png";
import designer7 from "../assets/designer7.png";
import { BiPound } from "react-icons/bi";
import gallary from "../assets/Gallary.png";

export default function Designer() {
  return (
    <div className="designer-wrapper">
      <div className="publication-wrapper">
        <Sidebar />
        <div className="d-flex bg-white justify-content-end">
          <Headers />
        </div>

        <div className="container-fluid p-0">
          <div className="bg-white">
            <Navbar />
          </div>

          <section className="bg-primary px-3 pt-3">
            <div className="row">
              <div className="col-12">
                <div className="container mission-inner-wrapper p-0">
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item ps-2">
                        <a
                          href="#"
                          className="text-decoration-none text-secondary fs-8"
                        >
                          HOME
                        </a>
                      </li>
                      <li className="breadcrumb-item ps-2">
                        <a
                          href="#"
                          className="text-decoration-none text-secondary fs-8"
                        >
                          FIND A DESIGNER
                        </a>
                      </li>

                      <li
                        className="breadcrumb-item active text-dark fw-600"
                        aria-current="page"
                      >
                        DESIGNER
                      </li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </section>

          <div className="">
            <div className="bg-white design-wrapper position-relative z-0"></div>
            <div className="container pb-5">
              <div className="row position-absolute z-4 design-img-wrapper">
                <div className="d-flex gap-5 justify-content-between">
                  <div className="col-3">
                    <img src={design1} />
                  </div>
                  <div className="d-flex flex-column justify-content-between">
                    <div className="col-9 px-2">
                      <Heads
                        className="fs-42 fw-bolder"
                        title="JOSHUA MARASCHIN"
                      />
                      <div className="images-contents-wrapper fs-6">
                        <div className="d-flex gap-2 pb-2">
                          <div>
                            <MdOutlineEmail />
                          </div>
                          <div>joshuamaraschin@gmail.com</div>
                        </div>
                        <div className="d-flex gap-2 pb-2">
                          <div>
                            <FaInstagram />
                          </div>
                          <div>@joshuamaraschin</div>
                        </div>
                        <div className="d-flex gap-2 pb-2">
                          <div>
                            <GoLocation />
                          </div>
                          <div>
                            Poplar Works, 384 Abbott Road, Studio 19, E14 0UX,
                            London, United Kingdom
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="">
                      <button type="button" className="btn btn-dark py-48">
                        REQUEST SERVICE
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="pt-5">
        <div className="bg-primary pt-5"></div>
        <div className="container bg-white p-5">
          <div className="row ">
            <h4 className="fw-bold fs-2 ps-4">OVERVIEW</h4>

            <div className="col-8 border-end">
              <div className="d-flex align-items-center gap-2 pt-4 pb-2 ps-3">
                <h5 className="fs-4 fw-500">Services</h5>
                <p>(Prices staring from)</p>
              </div>

              <div class="container mt-2">
                <div class="row">
                  <div class="col-md-6">
                    <ul class="list-group mb-4">
                      <li class="d-flex align-items-center py-3">
                        <img src={designer1} class="me-3" alt="Image 1" />
                        <div>
                          <p class="mb-1">
                            General Alters & Repairs (<BiPound /> 35)
                          </p>
                        </div>
                      </li>
                      <li class="d-flex align-items-center py-3">
                        <img src={designer2} class="me-3" alt="Image 2" />
                        <div>
                          <p class="mb-1">
                            Embeishment (<BiPound /> 35)
                          </p>
                        </div>
                      </li>
                      <li class="d-flex align-items-center py-3">
                        <img src={designer3} class="me-3" alt="Image 3" />
                        <div>
                          <p class="mb-1">
                            Reconstruction (<BiPound /> 35)
                          </p>
                        </div>
                      </li>
                      <li class="d-flex align-items-center py-3">
                        <img src={designer4} class="me-3" alt="Image 3" />
                        <div>
                          <p class="mb-1">
                            Embroidery (<BiPound /> 35)
                          </p>
                        </div>
                      </li>
                    </ul>
                  </div>

                  <div class="col-md-6">
                    <ul class="list-group mb-4">
                      <li class="d-flex align-items-center py-3">
                        <img src={designer5} class="me-3" alt="Image 5" />
                        <div>
                          <p class="mb-1">
                            Creative Lining (<BiPound /> 25)
                          </p>
                        </div>
                      </li>
                      <li class="d-flex align-items-center py-3">
                        <img src={designer6} class="me-3" alt="Image 6" />
                        <div>
                          <p class="mb-1">
                            Dye (<BiPound /> 25)
                          </p>
                        </div>
                      </li>
                      <li class="d-flex align-items-center py-3">
                        <img src={designer7} class="me-3" alt="Image 7" />
                        <div>
                          <p class="mb-1">
                            Paints (<BiPound /> 35)
                          </p>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-4 px-5">
              <div className="d-flex align-items-center gap-2 pt-4 pb-2 ps-3">
                <h5 className="fs-4 fw-500">Preferred Material</h5>
              </div>

              <div class="container mt-2">
                <div class="row">
                  <div class="col-md-6">
                    <ul class="list-group mb-4">
                      <li class="d-flex align-items-center py-3">
                        <div>
                          <p class="mb-1">Denim</p>
                        </div>
                      </li>
                      <li class="d-flex align-items-center py-3">
                        <div>
                          <p class="mb-1">Linen</p>
                        </div>
                      </li>
                      <li class="d-flex align-items-center py-3">
                        <div>
                          <p class="mb-1">Tweed</p>
                        </div>
                      </li>
                      <li class="d-flex align-items-center py-3">
                        <div>
                          <p class="mb-1">Velvet</p>
                        </div>
                      </li>
                    </ul>
                  </div>

                  <div class="col-md-6">
                    <ul class="list-group mb-4">
                      <li class="d-flex align-items-center py-3">
                        <div>
                          <p class="mb-1">Wool</p>
                        </div>
                      </li>
                      <li class="d-flex align-items-center py-3">
                        <div>
                          <p class="mb-1">Knitwear</p>
                        </div>
                      </li>
                      <li class="d-flex align-items-center py-3">
                        <div>
                          <p class="mb-1">Silk</p>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="pt-5 ">
        <div className="container bg-white">
          <section>
            <div className="row">
              <div className="col-12">
                <div className="container ">
                  <div>
                    <h3 className="fw-bold pt-5 pb-3">DESIGNER BIO</h3>
                    <p className="pb-3">
                      Joshua Maraschin is a London-based Brazilian designer who
                      has launched his eponymous brand at London Fashion Week,
                      in February 2020.
                    </p>
                    <p className="pb-5">
                      Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
                      sed diam nonumy eirmod tempor invidunt ut labore et dolore
                      magna aliquyam erat, sed diam voluptua. At vero eos et
                      accusam et justo duo dolores et ea rebum. Stet clita kasd
                      gubergren, no sea takimata sanctus est Lorem ipsum dolor
                      sit amet. Lorem ipsum dolor sit amet, consetetur
                      sadipscing elitr, sed diam nonumy eirmod tempor invidunt
                      ut labore et dolore magna aliquyam erat, sed diam
                      voluptua. At vero eos et accusam et justo duo dolores et
                      ea rebum. Stet clita kasd gubergren, no sea takimata
                      sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor
                      sit amet, consetetur sadipscing elitr, sed diam nonumy
                      eirmod tempor invidunt ut labore et dolore magna aliquyam
                      erat, sed diam voluptua. At vero eos et accusam et justo
                      duo dolores et ea rebum. Stet clita kasd
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>

      <div className="pt-5 pb-5">
        <div className="container bg-white">
          <section>
          <h3 className="fw-bold fs-2 pt-5 pb-3 ps-4 ">GALLARY</h3>
            <div className="row">
              <div className="col-12">
              <div class="designer-inner-wrap  p-0 container pb-5">
        <div class="row row-cols-1 row-cols-md-4 g-0 image-grid">
            <div class="col"><img src={gallary} alt="Image 1" class="img-fluid"/></div>
            <div class="col"><img src={gallary} alt="Image 2" class="img-fluid"/></div>
            <div class="col"><img src={gallary} alt="Image 3" class="img-fluid"/></div>
            <div class="col"><img src={gallary} alt="Image 4" class="img-fluid"/></div>
            <div class="col"><img src={gallary} alt="Image 5" class="img-fluid"/></div>
            <div class="col"><img src={gallary} alt="Image 6" class="img-fluid"/></div>
            <div class="col"><img src={gallary} alt="Image 7" class="img-fluid"/></div>
            <div class="col"><img src={gallary} alt="Image 8" class="img-fluid"/></div>
            <div class="col"><img src={gallary} alt="Image 9" class="img-fluid"/></div>
            <div class="col"><img src={gallary} alt="Image 10" class="img-fluid"/></div>
            <div class="col"><img src={gallary} alt="Image 11" class="img-fluid"/></div>
            <div class="col"><img src={gallary} alt="Image 12" class="img-fluid"/></div>
        </div>
    </div>
              </div>
            </div>
          </section>
        </div>
      </div>

      <div>
        <Footer/>
      </div>
    </div>
  );
}
