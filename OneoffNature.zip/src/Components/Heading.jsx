import React from "react";
import profile from "../assets/profile.svg";
import heart from "../assets/heart.svg";
import cart from "../assets/cart.svg";
import { Link } from "react-router-dom";

export default function Headers() {
  return (
    <div className="header-wrapper ps-5">
      <div className="row">
        <div className="col col-md-6 col-lg-6 d-flex " />
        <div className="profile-wrap d-flex align-items-center pt-1 pb-1 justify-content-start gap-2 ">
          <div className="d-flex border-end gap-2">
            <img src={profile} />
            <div className="dropdown profile-wrap pr-3">
              <a
                className="btn text-white bg-transparent d-flex justify-content-center align-items-center gap-3 shadow-none dropdown-toggle"
                href="#"
                type="button"
                id="dropdownMenuButton1"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                Profile
              </a>
              <ul
                className="dropdown-menu p-5 py-2"
                aria-labelledby="dropdownMenuButton1"
              >
                <li>
                  <a
                    className="d-flex justify-content-center text-decoration-none text-center"
                    href="#"
                  >
                    <Link to="/login">
                      <button className="bg-dark px-4 py-2 text-white fs-5">
                        Sign In
                      </button>
                    </Link>
                  </a>
                </li>
                <li>
                  <a className="dropdown-item border-bottom py-3" href="#">
                    New Customer?{" "}
                    <Link to="/logout" className="text-decoration-none">
                      <span className="text-blue fw-500 ps-1">Signup</span>
                    </Link>
                  </a>
                </li>
                <li>
                  <a className="dropdown-item border-bottom py-2" href="#">
                    My Profile
                  </a>
                </li>
                <li>
                  <a className="dropdown-item border-bottom py-2" href="#">
                    My Orders
                  </a>
                </li>
                <li>
                  <a className="dropdown-item border-bottom py-2" href="#">
                    My Wishlist
                  </a>
                </li>
                <li>
                  <a className="dropdown-item border-bottom py-2" href="#">
                    Address Book
                  </a>
                </li>
                <li>
                  <a className="dropdown-item border-bottom py-2" href="#">
                    Stored Payment Method
                  </a>
                </li>
                <li>
                  <a className="dropdown-item border-bottom py-2" href="#">
                    My Product Reviews
                  </a>
                </li>
                <li>
                  <a className="dropdown-item py-2" href="#">
                    Newsletter Subscription
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="d-flex align-items-center justify-content-center gap-2 border-end">
            <img src={heart} alt="" className="ps-3" />
            <span className="pe-3"> Favourite</span>
          </div>

          <div className="d-flex align-items-center justify-content-center gap-2">
            <img src={cart} alt="" className="ps-3" />
            <span className="pe-3">Cart</span>
          </div>
        </div>
      </div>
    </div>
  );
}
