import React, { useState } from "react";
import Heads from "./Heads";
import Headers from "./Heading";
import Navbar from "./Navbar";
import pound from "../assets/pound.png";
import { FiUpload } from "react-icons/fi";
import Footer from "./Footer";

export default function Request() {
  const [file, setFile] = useState(null);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = () => {
    console.log("File to upload:", file);
  };
  return (
    <div className="request-wrapper">
      <div className="d-flex justify-content-end bg-white">
        <Headers />
      </div>
      <div className="bg-white">
        <Navbar />
      </div>
      <div className="container pb-5">
        <div className="pt-5">
          <div className="bg-white">
            <div className="pt-5 p-5 border-bottom-light">
              <Heads className="fs-42 fw-bolder pb-3" title="REQUEST SERVICE" />

              <p className="text-secondary fs-6"> Selected Designer</p>
              <p className="text-dark fs-5 p-0">Joshua Maraschin</p>
            </div>

            <div className="pt-3 ps-5">
              <div className="d-flex pb-2 gap-2 fs-5">
                <p>Service Type</p>
                <p>(Prices staring from)</p>
              </div>

              <div className="d-flex gap-5">
                <div class="form-check">
                  <input
                    class="form-check-input bg-dark border-0"
                    type="checkbox"
                    value=""
                    id="flexCheckChecked"
                    checked
                  />
                  <label class="form-check-label" for="flexCheckChecked">
                    Paint
                    <span className="ps-2">
                      (<img src={pound} /> 35 )
                    </span>
                  </label>
                </div>

                <div class="form-check">
                  <input
                    class="form-check-input border-0 bg-dark"
                    type="checkbox"
                    value=""
                    id="flexCheckChecked"
                    checked
                  />
                  <label class="form-check-label" for="flexCheckChecked">
                    Patch
                    <span className="ps-2">
                      (<img src={pound} /> 35 )
                    </span>
                  </label>
                </div>

                <div class="form-check">
                  <input
                    class="form-check-input bg-dark border-0"
                    type="checkbox"
                    value=""
                    id="flexCheckChecked"
                    checked
                  />
                  <label class="form-check-label" for="flexCheckChecked">
                    Repurpose
                    <span className="ps-2">
                      (<img src={pound} /> 35 )
                    </span>
                  </label>
                </div>
              </div>
            </div>

            <div className="pt-3 ps-5">
              <div className="d-flex pb-2 gap-2 fs-5">
                <p>Material</p>
              </div>

              <div className="d-flex gap-5">
                <div class="form-check">
                  <input
                    class="form-check-input bg-dark border-0"
                    type="checkbox"
                    value=""
                    id="flexCheckChecked"
                    checked
                  />
                  <label class="form-check-label" for="flexCheckChecked">
                    Denim
                  </label>
                </div>

                <div class="form-check">
                  <input
                    class="form-check-input border-0 bg-dark"
                    type="checkbox"
                    value=""
                    id="flexCheckChecked"
                    checked
                  />
                  <label class="form-check-label" for="flexCheckChecked">
                    Linen
                  </label>
                </div>

                <div class="form-check">
                  <input
                    class="form-check-input bg-dark border-0"
                    type="checkbox"
                    value=""
                    id="flexCheckChecked"
                    checked
                  />
                  <label class="form-check-label" for="flexCheckChecked">
                    Tweed
                  </label>
                </div>

                <div class="form-check">
                  <input
                    class="form-check-input bg-dark border-0"
                    type="checkbox"
                    value=""
                    id="flexCheckChecked"
                    checked
                  />
                  <label class="form-check-label" for="flexCheckChecked">
                    Knitwear
                  </label>
                </div>

                <div class="form-check pb-4">
                  <input
                    class="form-check-input bg-dark border-0"
                    type="checkbox"
                    value=""
                    id="flexCheckChecked"
                    checked
                  />
                  <label class="form-check-label" for="flexCheckChecked">
                    Velvet
                  </label>
                </div>
              </div>
              <div class="row mb-3 pe-5">
                <div class="col-12">
                  <label for="comments" class="form-label m-0 pb-1">
                    Service Description
                  </label>
                  <textarea
                    class="form-control p-2"
                    id="comments"
                    rows="3"
                    placeholder="Enter the Service Description, ex. Garment Brand, Size Change, New Colour etc"
                  ></textarea>
                </div>
              </div>

              <div class="row mb-3 pe-5">
                <div class="col-12">
                  <label for="comments" class="form-label m-0 pb-1">
                    <div className="d-flex gap-2">
                      Upload Garment Images
                      <p>( Image size can not exceeded 2MB)</p>
                    </div>
                  </label>
                  <div className="border-1 border-dotted">
                    <div className="row mb-3 pe-5">
                      <div className="container mt-4">
                        <div className="mb-3 text-center">
                          <FiUpload />
                          <div className="input-group justify-content-around  text-center pb-2">
                            <input
                              type="file"
                              className="form-control"
                              id="formFile"
                              onChange={handleFileChange}
                              style={{ display: "none" }}
                            />

                            <button
                              type="button"
                              class="btn btn-light border-1 border px-4 text-center"
                              onClick={() =>
                                document.getElementById("formFile").click()
                              }
                            >
                              {" "}
                              Browse
                            </button>

                            {file && <span className="ms-2">{file.name}</span>}
                          </div>
                          <div className="d-flex fs-10 justify-content-center">
                            <p>Supports : Jpeg / Png</p>
                            <p>(Max 5 images can upload)</p>
                          </div>
                        </div>
                        {file && <div></div>}
                      </div>
                     
                    </div>
                    
                  </div>
                  <div className="d-flex justify-content-end gap-3 pt-5 pb-5">
                        <button type="button" class="btn border-1 border px-5 py-2">
                        CANCEL
                        </button>
                        <button type="button" class="btn btn-dark px-4 py-2">
                        SUBMIT REQUEST
                        </button>
                      </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div>
        <Footer/>
        </div>
    </div>
  );
}
