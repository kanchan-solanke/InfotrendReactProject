import React from "react";
import Heads from "./Heads";
import location from "../assets/location.svg";
import phone from "../assets/phone.svg";
import email from "../assets/email.svg";
import { MdKeyboardArrowRight } from "react-icons/md";
import facebook from "../assets/facebook.svg";
import twitter from "../assets/twitter.svg";
import Linkedin from "../assets/Linkedin.svg";

export default function Footer() {
  return (
    <div className="footer-wrapper bg-dark-0 pt-5 ">
      <div className="container">
        <div className="row">
          <div className="col-12 col-md-4 col-lg-4">
            <div>
              <Heads className="text-white" title="CONTACT INFORMATION" />
            </div>
            <div className="contact-info-wrapper ">
              <div className="d-flex gap-3 border-bottom pt-4 pb-4">
                <div>
                  <img src={location} />
                </div>
                <div>
                  <div>
                    <span className="fs-16 text-white">Address</span>
                  </div>
                  <div>
                    <p className="text-white-50">
                      Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
                      sed diam
                    </p>
                  </div>
                </div>
              </div>

              <div className="d-flex gap-3 border-bottom pt-4 pb-4">
                <div>
                  <img src={phone} />
                </div>
                <div>
                  <div>
                    <span className="fs-16 text-white">Mobile Number</span>
                  </div>
                  <div>
                    <p className="text-white-50">1234567890</p>
                  </div>
                </div>
              </div>
              <div className="d-flex gap-3 pt-4 pb-4">
                <div>
                  <img src={email} />
                </div>
                <div>
                  <div>
                    <span className="fs-16 text-white">Email</span>
                  </div>
                  <div>
                    <p className="text-white-50">Oneoffnature@gmail.com</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="col col-md-8 col-lg-8 ps-5">
            <div className="row border-bottom">
              <div className="col-md-4">
                <div>
                  <Heads className="text-white" title="QUICK LINKS" />
                </div>
                <div className=" ">
                  <div className="d-flex gap-2 pt-4 pb-2">
                    <MdKeyboardArrowRight />

                    <span className="text-white-50">About</span>
                  </div>
                  <div className="d-flex gap-2 pt-3 pb-2">
                    <MdKeyboardArrowRight />

                    <span className="text-white-50">Marketplace</span>
                  </div>
                  <div className="d-flex gap-2 pt-3 pb-2">
                    <MdKeyboardArrowRight />

                    <span className="text-white-50">Blogs</span>
                  </div>
                  <div className="d-flex gap-2 pt-3 pb-4">
                    <MdKeyboardArrowRight />

                    <span className="text-white-50">Designer</span>
                  </div>
                </div>
              </div>
              <div className="col-md-8">
                <div>
                  <Heads className="text-white" title="JOIN US" />
                </div>
                <div className="pt-4">
                  <p className="p-0 pb-4 text-white-50">
                    Subscribe to get latest offer
                  </p>
                  <div className="position-relative email-footer-wraps">
                    <img src={email} alt="" className="position-absolute" />

                    <input
                      type="email"
                      placeholder="Email"
                      className="px-3 ps-5 py-2 bg-transparent"
                    />
                    <button type="button" class="btn btn-light px-3 py-2">
                      Subscribe
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div className="row">
              {" "}
              <div className="d-flex gap-3">
                <div className="pt-4">
                  <Heads title="FOLLOW US" className="text-nowrap text-white" />
                </div>
                <div className="d-flex footer-img-wrap pt-3 gap-2">
                  <img src={facebook} alt="" />
                  <img src={twitter} alt="" />
                  <img src={Linkedin} alt="" />
                  <img src={facebook} alt="" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="row pe-3">
        <p className="d-flex justify-content-center copy-wrap text-white-50 pt-2 pb-1">
          Copyright @ oneofNatureex.com 2020. All Rights Reserved.
        </p>
      </div>
    </div>
  );
}
