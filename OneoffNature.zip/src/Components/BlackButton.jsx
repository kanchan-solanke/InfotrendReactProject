import React from "react";

export default function BlackButton({ buttonText }) {
  return (
    <div className="black-wrap">
      <button type="submit" className="btn">
        {buttonText}
      </button>
    </div>
  );
}
