import React from "react";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import Footer from "./Footer";
import Layout from "./Layout";
import Navbar from "./Navbar";
import Request from "./Request";
import Sidebar from "./Sidebar";
import SignIn from "./Form/SignIn";
import PriceDetails from "./PriceDetails";
import Order from "./Order";
import PriceTable from "./PriceTable";
import ShoppingCart from "./ShoppingCart";
import SignOut from "./Form/SignOut";
import Mission from "./Mission";
import FashionTrend from "./FashionTrend";
import Publications from "./Publications";
import RequestSubmit from "./RequestSubmit";
import Modal from "./Modal";
import Designer from "./Designer";
import Upcycle from "./Upcycle";
import CarouselBackground from "./CarouselBackground";
import Home from "./Home";
import Shop from "./Shop";
import ShippingAdd from "./ShippingAdd";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Home/>

  },
  {
    path: "/navbar",
    element: <Navbar />,
  },
  {
    path: "/footer",
    element: <Footer />,
  },
  {
    path: "/side",
    element: <Sidebar />,
  },
  {
    path: "/request",
    element: <Request />,
  },
  {
    path: "/login",
    element: <SignIn />,
  },
  {
    path: "/price",
    element: <PriceDetails />,
  },
  {
    path: "/order",
    element: <Order />,
  },
  {
    path: "/pricetable",
    element: <PriceTable />,
  },
  {
    path: "/cart",
    element: <ShoppingCart />,
  },
  {
    path: "/logout",
    element: <SignOut />,
  },
  {
    path: "/mission",
    element: <Mission />,
  },
  {
    path: "/trend",
    element: <FashionTrend />,
  },
  {
    path: "/publication",
    element: <Publications />,
  },
  {
    path: "/request",
    element: <Request />,
  },
  {
    path: "/requestsubmit",
    element: <RequestSubmit />,
  },
  {
    path: "/modal",
    element: <Modal />,
  },
  {
    path: "/designer",
    element: <Designer />,
  },
  {
    path: "/upcycle",
    element: <Upcycle/>,
  },
  {
    path: "/carouselbg",
    element: <CarouselBackground/>,
  },
  {
    path: "/shop",
    element: <Shop/>,
  },
  {
    path: "/shipping",
    element: <ShippingAdd/>,
  },
]);

export default function Main() {
  return <RouterProvider router={router} />;
}
