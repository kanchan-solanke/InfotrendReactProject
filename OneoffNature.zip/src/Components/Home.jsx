import React from "react";
import Headers from "./Heading";
import Sidebar from "./Sidebar";
import Footer from "./Footer";
import Navbar from "./Navbar";
import mission from "../assets/mission.png";
import supply from "../assets/supply.png";
import material from "../assets/material.png";
import conduct from "../assets/conduct.png";
import values from "../assets/values.png";
import brand from "../assets/brand.png";
import store from "../assets/store.png";
import ethical from "../assets/ethical.png";
import design from "../assets/design.png";
import market from "../assets/Marketplace.svg";
import Heads from "./Heads";
import designer from "../assets/DesignerIcon.svg";
import { IoIosArrowForward } from "react-icons/io";
import { IoIosHeartEmpty } from "react-icons/io";
import pound from "../assets/pound.png";
import home1 from "../assets/home1.png";
import home2 from "../assets/home2.png";
import home3 from "../assets/home3.png";
import homeflex from "../assets/homeflex.png";
import homeflex1 from "../assets/homeflex1.png";
import homeflex2 from "../assets/homeflex2.png";
import homeflex4 from "../assets/homeflex4.png";

import homeImg from "../assets/homeImg.png";
import shop from "../assets/ShopIcon.svg";
import uflex3 from "../assets/uflex3.png";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
export default function Home() {
  const home = {
    dots: true,
    infinite: true,
    nav: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
  };

  const settings = {
    infinite: true,

    nav: true,
    slidesToShow: 4,
    slidesToScroll: 1,
  };
  return (
    <>
      <div className="home-wrapper">
        <Sidebar />
        <div className="d-flex justify-content-end bg-white">
          <Headers />
        </div>

        <div className="bg-white">
          <Navbar />
        </div>

        <div className="">
          <div className="row">
            <div className="col-12">
              <div className="carousel-background-wrapper  ">
                <Slider {...home}>
                  <div className="carousel-item position-relative ">
                    <img
                      src={homeImg}
                      className="d-block img-fluid"
                      alt="First slide"
                    />
                    {/* <div className="overlay-content position-absolute text-dark rounded">
                      <div>
                        <h3 className="pb-3 position-absolute fw-bold fs-2">
                          ONE OF A KIND,
                          <div>MADE TO MEASURE</div>
                          <div>ETHICAL X SUSTAINABLE FASHION</div>
                        </h3>
                      </div>

                      <p className="pb-5">
                        ONEOFFNATURE is a digital platform connecting you with
                        some of the most innovative emerging sustainable
                        designers to upcycle your used garments into a one of a
                        kind piece. By Upcycling not only are you giving your
                        clothes a new lease of life and helping reduce landfill
                        waste.
                      </p>
                      <div className="pb-5">
                        <button
                          className="bg-dark btn px-4 py-2 text-white mb-3"
                          type="button"
                        >
                          UPCYCLE NOW
                        </button>
                      </div>
                    </div> */}
                  </div>
                  <div className="carousel-item position-relative">
                    <img
                      src={homeImg}
                      className="d-block w-100"
                      alt="Second slide"
                    />
                    {/* <div className="overlay-content text-dark rounded">
                      <h3 className="pb-3 fw-bold fs-2">
                        ONE OF A KIND,
                        <div>MADE TO MEASURE</div>
                        <div>ETHICAL X SUSTAINABLE FASHION</div>
                      </h3>
                      <p className="pb-5">
                        ONEOFFNATURE is a digital platform connecting you with
                        some of the most innovative emerging sustainable
                        designers to upcycle your used garments into a one of a
                        kind piece. By Upcycling not only are you giving your
                        clothes a new lease of life and helping reduce landfill
                        waste..
                      </p>
                      <div className="pb-5">
                        <button
                          className="bg-dark btn px-4 py-2 text-white mb-3"
                          type="button"
                        >
                          UPCYCLE NOW
                        </button>
                      </div>
                    </div> */}
                  </div>
                  <div className="carousel-item position-relative">
                    <img
                      src={homeImg}
                      className="d-block w-100"
                      alt="Third slide"
                    />
                    {/* <div className="overlay-content bg-dark text-white p-3 rounded">
                      <h3 className="pb-3 fw-bold fs-2">
                        ONE OF A KIND,
                        <div>MADE TO MEASURE</div>
                        <div>ETHICAL X SUSTAINABLE FASHION</div>
                      </h3>
                      <p className="pb-5">
                        ONEOFFNATURE is a digital platform connecting you with
                        some of the most innovative emerging sustainable
                        designers to upcycle your used garments into a one of a
                        kind piece. By Upcycling not only are you giving your
                        clothes a new lease of life and helping reduce landfill
                        waste..
                      </p>
                    </div> */}
                  </div>
                </Slider>
              </div>
            </div>
          </div>
          <div className="container-fluid">
            <section className="pb-5">
              <div className="position-relative">
                <div className="blue-background"></div>
                <div className="home-slick">
                  <div className="d-flex justify-content-between pb-5">
                    <h3>
                      <Heads title="FEATURED" className="fs-42 fw-bold" />
                    </h3>
                    <button
                      type="button"
                      class="btn border-1 bg-white border px-3 fw-600 py-2"
                    >
                      EXPLORE ALL
                    </button>
                  </div>
                  <Slider {...settings}>
                    <div>
                      <img
                        src={uflex3}
                        alt="Image 1"
                        className="img-fluid w-100 p-2"
                      />
                      <div>
                        <div className="d-flex justify-content-between">
                          <div className="fw-600">
                            Women 50s Vintage Sleeve...
                          </div>
                          <div className="pe-3">
                            <IoIosHeartEmpty />
                          </div>
                        </div>
                        <div className="text-secondary">GRACE KARIN</div>
                        <div className="d-flex gap-2">
                          <div className="d-flex align-items-center">
                            <img
                              src={pound}
                              alt=""
                              style={{ width: "9px", height: "13px" }}
                            />
                            <div className="text-dark">40.00</div>
                          </div>
                          <div className="d-flex align-items-center text-secondary text-decoration-line-through">
                            <img
                              src={pound}
                              alt=""
                              style={{ width: "9px", height: "13px" }}
                            />
                            <div>40.00</div>
                          </div>
                          <div className="text-warning">(50% Off)</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <img
                        src={uflex3}
                        alt="Image 2"
                        className="img-fluid w-100 p-2"
                      />
                      <div>
                        <div className="d-flex justify-content-between">
                          <div className="fw-600">
                            Women 50s Vintage Sleeve...
                          </div>
                          <div className="pe-3">
                            <IoIosHeartEmpty />
                          </div>
                        </div>
                        <div className="text-secondary">GRACE KARIN</div>
                        <div className="d-flex gap-2">
                          <div className="d-flex align-items-center">
                            <img
                              src={pound}
                              alt=""
                              style={{ width: "9px", height: "13px" }}
                            />
                            <div className="text-dark">40.00</div>
                          </div>
                          <div className="d-flex align-items-center text-secondary text-decoration-line-through">
                            <img
                              src={pound}
                              alt=""
                              style={{ width: "9px", height: "13px" }}
                            />
                            <div>40.00</div>
                          </div>
                          <div className="text-warning">(50% Off)</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <img
                        src={uflex3}
                        alt="Image 3"
                        className="img-fluid w-100 p-2"
                      />
                      <div>
                        <div className="d-flex justify-content-between">
                          <div className="fw-600">
                            Women 50s Vintage Sleeve...
                          </div>
                          <div>
                            <IoIosHeartEmpty />
                          </div>
                        </div>
                        <div className="text-secondary">GRACE KARIN</div>
                        <div className="d-flex gap-2">
                          <div className="d-flex align-items-center">
                            <img
                              src={pound}
                              alt=""
                              style={{ width: "9px", height: "13px" }}
                            />
                            <div className="text-dark">40.00</div>
                          </div>
                          <div className="d-flex align-items-center text-secondary text-decoration-line-through">
                            <img
                              src={pound}
                              alt=""
                              style={{ width: "9px", height: "13px" }}
                            />
                            <div>40.00</div>
                          </div>
                          <div className="text-warning">(50% Off)</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <img
                        src={uflex3}
                        alt="Image 4"
                        className="img-fluid w-100 p-2"
                      />
                      <div>
                        <div className="d-flex justify-content-between">
                          <div className="fw-600">
                            Women 50s Vintage Sleeve...
                          </div>
                          <div>
                            <IoIosHeartEmpty />
                          </div>
                        </div>
                        <div className="text-secondary">GRACE KARIN</div>
                        <div className="d-flex gap-2">
                          <div className="d-flex align-items-center">
                            <img
                              src={pound}
                              alt=""
                              style={{ width: "9px", height: "13px" }}
                            />
                            <div className="text-dark">40.00</div>
                          </div>
                          <div className="d-flex align-items-center text-secondary text-decoration-line-through">
                            <img
                              src={pound}
                              alt=""
                              style={{ width: "9px", height: "13px" }}
                            />
                            <div>40.00</div>
                          </div>
                          <div className="text-warning">(50% Off)</div>
                        </div>
                      </div>
                    </div>
                  </Slider>
                </div>
              </div>
            </section>

            <section className="pt-5 bg-white">
              <div className="home-slick-wraps container">
                <div className="d-flex justify-content-between pb-5">
                  <h3>
                    <Heads title="NEW IN" className="fs-42 fw-bold" />
                  </h3>
                  <button
                    type="button"
                    class="btn border-1 bg-white border px-3 fw-600 py-2"
                  >
                    EXPLORE ALL
                  </button>
                </div>
                <Slider {...settings}>
                  <div>
                    <img
                      src={homeflex}
                      alt="Image 1"
                      className="img-fluid w-100 p-2"
                    />
                    <div>
                      <div className="d-flex justify-content-between">
                        <div className="fw-600">
                          Women 50s Vintage Sleeve...
                        </div>
                        <div className="pe-3">
                          <IoIosHeartEmpty />
                        </div>
                      </div>
                      <div className="text-secondary">GRACE KARIN</div>
                      <div className="d-flex gap-2">
                        <div className="d-flex align-items-center">
                          <img
                            src={pound}
                            alt=""
                            style={{ width: "9px", height: "13px" }}
                          />
                          <div className="text-dark">40.00</div>
                        </div>
                        <div className="d-flex align-items-center text-secondary text-decoration-line-through">
                          <img
                            src={pound}
                            alt=""
                            style={{ width: "9px", height: "13px" }}
                          />
                          <div>40.00</div>
                        </div>
                        <div className="text-warning">(50% Off)</div>
                      </div>
                    </div>
                  </div>
                  <div>
                    <img
                      src={homeflex1}
                      alt="Image 2"
                      className="img-fluid w-100 p-2"
                    />
                    <div>
                      <div className="d-flex justify-content-between">
                        <div className="fw-600">
                          Women 50s Vintage Sleeve...
                        </div>
                        <div className="pe-3">
                          <IoIosHeartEmpty />
                        </div>
                      </div>
                      <div className="text-secondary">GRACE KARIN</div>
                      <div className="d-flex gap-2">
                        <div className="d-flex align-items-center">
                          <img
                            src={pound}
                            alt=""
                            style={{ width: "9px", height: "13px" }}
                          />
                          <div className="text-dark">40.00</div>
                        </div>
                        <div className="d-flex align-items-center text-secondary text-decoration-line-through">
                          <img
                            src={pound}
                            alt=""
                            style={{ width: "9px", height: "13px" }}
                          />
                          <div>40.00</div>
                        </div>
                        <div className="text-warning">(50% Off)</div>
                      </div>
                    </div>
                  </div>
                  <div>
                    <img
                      src={homeflex2}
                      alt="Image 3"
                      className="img-fluid w-100 p-2"
                    />
                    <div>
                      <div className="d-flex justify-content-between">
                        <div className="fw-600">
                          Women 50s Vintage Sleeve...
                        </div>
                        <div className="pe-3">
                          <IoIosHeartEmpty />
                        </div>
                      </div>
                      <div className="text-secondary">GRACE KARIN</div>
                      <div className="d-flex gap-2">
                        <div className="d-flex align-items-center">
                          <img
                            src={pound}
                            alt=""
                            style={{ width: "9px", height: "13px" }}
                          />
                          <div className="text-dark">40.00</div>
                        </div>
                        <div className="d-flex align-items-center text-secondary text-decoration-line-through">
                          <img
                            src={pound}
                            alt=""
                            style={{ width: "9px", height: "13px" }}
                          />
                          <div>40.00</div>
                        </div>
                        <div className="text-warning">(50% Off)</div>
                      </div>
                    </div>
                  </div>
                  <div>
                    <img
                      src={homeflex4}
                      alt="Image 4"
                      className="img-fluid w-100 p-2"
                    />
                    <div>
                      <div className="d-flex justify-content-between">
                        <div className="fw-600">
                          Women 50s Vintage Sleeve...
                        </div>
                        <div className="pe-3">
                          <IoIosHeartEmpty />
                        </div>
                      </div>
                      <div className="text-secondary">GRACE KARIN</div>
                      <div className="d-flex gap-2">
                        <div className="d-flex align-items-center">
                          <img
                            src={pound}
                            alt=""
                            style={{ width: "9px", height: "13px" }}
                          />
                          <div className="text-dark">40.00</div>
                        </div>
                        <div className="d-flex align-items-center text-secondary text-decoration-line-through">
                          <img
                            src={pound}
                            alt=""
                            style={{ width: "9px", height: "13px" }}
                          />
                          <div>40.00</div>
                        </div>
                        <div className="text-warning">(50% Off)</div>
                      </div>
                    </div>
                  </div>
                </Slider>
              </div>
            </section>

            <div className="pt-4">
              <section className="pt-5 pb-5 bg-white">
                <div className="home-slick-wraps  container">
                  <div className="d-flex justify-content-between pb-5">
                    <h3>
                      <Heads title="EDITORS PICKS" className="fs-42 fw-bold" />
                    </h3>
                    <button
                      type="button"
                      class="btn border-1 bg-white border px-3 fw-600 py-2"
                    >
                      EXPLORE ALL
                    </button>
                  </div>
                  <Slider {...settings}>
                    <div>
                      <img
                        src={uflex3}
                        alt="Image 1"
                        className="img-fluid w-100 p-2"
                      />
                      <div>
                        <div className="d-flex justify-content-between">
                          <div className="fw-600">
                            Women 50s Vintage Sleeve...
                          </div>
                          <div className="pe-3">
                            <IoIosHeartEmpty />
                          </div>
                        </div>
                        <div className="text-secondary">GRACE KARIN</div>
                        <div className="d-flex gap-2">
                          <div className="d-flex align-items-center">
                            <img
                              src={pound}
                              alt=""
                              style={{ width: "9px", height: "13px" }}
                            />
                            <div className="text-dark">40.00</div>
                          </div>
                          <div className="d-flex align-items-center text-secondary text-decoration-line-through">
                            <img
                              src={pound}
                              alt=""
                              style={{ width: "9px", height: "13px" }}
                            />
                            <div>40.00</div>
                          </div>
                          <div className="text-warning">(50% Off)</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <img
                        src={homeflex}
                        alt="Image 2"
                        className="img-fluid w-100 p-2"
                      />
                      <div>
                        <div className="d-flex justify-content-between">
                          <div className="fw-600">
                            Women 50s Vintage Sleeve...
                          </div>
                          <div className="pe-3">
                            <IoIosHeartEmpty />
                          </div>
                        </div>
                        <div className="text-secondary">GRACE KARIN</div>
                        <div className="d-flex gap-2">
                          <div className="d-flex align-items-center">
                            <img
                              src={pound}
                              alt=""
                              style={{ width: "9px", height: "13px" }}
                            />
                            <div className="text-dark">40.00</div>
                          </div>
                          <div className="d-flex align-items-center text-secondary text-decoration-line-through">
                            <img
                              src={pound}
                              alt=""
                              style={{ width: "9px", height: "13px" }}
                            />
                            <div>40.00</div>
                          </div>
                          <div className="text-warning">(50% Off)</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <img
                        src={homeflex2}
                        alt="Image 3"
                        className="img-fluid w-100 p-2"
                      />
                      <div>
                        <div className="d-flex justify-content-between">
                          <div className="fw-600">
                            Women 50s Vintage Sleeve...
                          </div>
                          <div className="pe-3">
                            <IoIosHeartEmpty />
                          </div>
                        </div>
                        <div className="text-secondary">GRACE KARIN</div>
                        <div className="d-flex gap-2">
                          <div className="d-flex align-items-center">
                            <img
                              src={pound}
                              alt=""
                              style={{ width: "9px", height: "13px" }}
                            />
                            <div className="text-dark">40.00</div>
                          </div>
                          <div className="d-flex align-items-center text-secondary text-decoration-line-through">
                            <img
                              src={pound}
                              alt=""
                              style={{ width: "9px", height: "13px" }}
                            />
                            <div>40.00</div>
                          </div>
                          <div className="text-warning">(50% Off)</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <img
                        src={homeflex4}
                        alt="Image 4"
                        className="img-fluid w-100 p-2"
                      />
                      <div>
                        <div className="d-flex justify-content-between">
                          <div className="fw-600">
                            Women 50s Vintage Sleeve...
                          </div>
                          <div className="pe-3">
                            <IoIosHeartEmpty />
                          </div>
                        </div>
                        <div className="text-secondary">GRACE KARIN</div>
                        <div className="d-flex gap-2">
                          <div className="d-flex align-items-center">
                            <img
                              src={pound}
                              alt=""
                              style={{ width: "9px", height: "13px" }}
                            />
                            <div className="text-dark">40.00</div>
                          </div>
                          <div className="d-flex align-items-center text-secondary text-decoration-line-through">
                            <img
                              src={pound}
                              alt=""
                              style={{ width: "9px", height: "13px" }}
                            />
                            <div>40.00</div>
                          </div>
                          <div className="text-warning">(50% Off)</div>
                        </div>
                      </div>
                    </div>
                  </Slider>
                </div>
              </section>
            </div>

            <div className="pt-4">
              <section className="pt-5 pb-5 bg-dark">
                <div className="container">
                  <div className="row">
                    <div className="col-12">
                      <div className="d-flex justify-content-between pb-5">
                        <h3>
                          <Heads
                            title="SHOP BY CATEGORIES"
                            className="fs-42 fw-bold text-white"
                          />
                        </h3>
                        <button
                          type="button"
                          class="btn border-1 bg-white border px-3 fw-600 py-2"
                        >
                          EXPLORE ALL
                        </button>
                      </div>
                      <div className="d-flex flex-column gap-5">
                        <div className="d-flex gap-4 position-relative">
                          <img
                            src={home1}
                            alt="Image 1"
                            className="img-fluid w-100"
                          />

                          {/* <button className="bg-white text-dark position-absolute mens-wear-wrapper border-0 rounded-3 fs-3 fw-600 py-3">
                            Mens Wear
                          </button> */}
                          <img
                            src={home2}
                            alt="Image 2"
                            className="img-fluid w-100"
                          />
                          {/* <button className="bg-white text-dark position-absolute womens-wear-wrapper border-0 rounded-3 fs-3 fw-600 py-3">
                            Womens Wear
                          </button> */}
                        </div>

                        <div className="p-0">
                          <img
                            src={home3}
                            alt="Image 3"
                            className="img-fluid w-100"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            </div>

            <section>
              <div className="work-container bg-primary">
                <div className="container flex-wraps-upcycle mt-5 pt-2 pb-5">
                  <div>
                    <h2 className="fs-42 fw-600 pb-2">HOW WE WORK</h2>
                    <p className="pb-4">
                      To ensure you know our sustainability and values are
                      shared between us and all of our brands, each one is
                      assigned one or more of our 3 distinct values. Symbols
                      have been created to assign the values of sustainability,
                      ethical practice and social elements to each brand,
                      appearing under their 'brand values' on their collection
                      pages.
                    </p>
                  </div>
                  <div className="row justify-content-center home-margin-wraps">
                    <div className="col-md-4 mb-4">
                      <div className="card card-custom pb-5 pt-5 px-3 border-0 h-100  rounded">
                        <div
                          className="d-flex justify-content-center align-items-center"
                          style={{ height: "184px" }}
                        >
                          <img
                            src={ethical}
                            className="card-img-top img-fluid"
                            style={{ maxHeight: "184px", maxWidth: "184px" }}
                            alt="Ethical Sustainable Shop"
                          />
                        </div>
                        <div className="card-body px-5">
                          <h5 className="card-title fw-500">
                            Ethical X Sustainable Shop
                          </h5>
                          <p className="card-text">
                            Seamlessly search through ranges of carefully
                            curated sustainable one-of-a-kind handmade garments
                            from some of the brightest emerging ethical x
                            sustainable designers.
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-4 mb-4">
                      <div className="card card-custom pb-5 pt-5 px-3 h-100 border-0 rounded">
                        <div
                          className="d-flex justify-content-center align-items-center"
                          style={{ height: "184px" }}
                        >
                          <img
                            src={design}
                            className="card-img-top img-fluid"
                            style={{ maxHeight: "184px", maxWidth: "184px" }}
                            alt="Support Sustainable Designer"
                          />
                        </div>
                        <div className="card-body px-5">
                          <h5 className="card-title fw-500">
                            Support Sustainable Designer
                          </h5>
                          <p className="card-text">
                            Supporting emerging ethical x sustainable designers,
                            with comprehensive summaries offer to look critical
                            areas from growing to establishing your brand.
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-4 mb-4">
                      <div className="card card-custom pb-5 pt-5 px-3 border-0 h-100 rounded">
                        <div
                          className="d-flex justify-content-center align-items-center"
                          style={{ height: "184px" }}
                        >
                          <img
                            src={market}
                            className="card-img-top img-fluid"
                            style={{ maxHeight: "184px", maxWidth: "184px" }}
                            alt="Upcycle Marketplace"
                          />
                        </div>
                        <div className="card-body px-5">
                          <h5 className="card-title fw-500">
                            Upcycle Marketplace
                          </h5>
                          <p className="card-text">
                            Have your unwanted clothes revitalized and
                            reimagined into a made to measure, tailored, one of
                            a kind piece by one of our designer.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="blue-background"></div>
            </section>

            <div>
              <Footer />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
