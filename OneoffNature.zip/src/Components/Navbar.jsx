import React from "react";
import ONEOFFNature from "../assets/ONEOFFNature.svg";
import search from "../assets/search.svg";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import Upcycle from "./Upcycle";
export default function Navbar() {
  return (
    <div className="navbar-wrapper">
      <div className="container ">
        <div className="row">
          <div className="col-12 pe-0">
            <nav class="bg-transparent navbar navbar-expand-lg navbar-light">
              <div class="align-items-center d-flex flex-md-nowrap flex-nowrap bg-transparent justify-content-between text-nowrap w-100 p-0 pe-3">
                <a class="navbar-brand p-0" href="#">
                  <img src={ONEOFFNature} alt="ONEOFFNature Logo" />
                </a>
                <button
                  class="navbar-toggler navbar-toggler-nav"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <span class="navbar-toggler-icon"></span>
                </button>
                <div
                  class="collapse  navbar-collapse navbar-collapse-wrap show text-center  w-100"
                  id="navbarSupportedContent"
                >
                  <ul class="d-flex mb-2 mb-lg-0 navbar-nav">
                    <li class="nav-item dropdown">
                      <a
                        class="align-items-center d-flex dropdown-toggle gap-1 nav-link justify-content-center"
                        href="#"
                        style={{ color: "#403449" }}
                        id="navbarDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        Shop
                      </a>
                      <ul
                        class="dropdown-menu"
                        aria-labelledby="navbarDropdown"
                      >
                        <li>
                          <a class="dropdown-item" href="#">
                            Action
                          </a>
                        </li>
                        <li>
                          <a class="dropdown-item" href="#">
                            Another action
                          </a>
                        </li>
                        <li>
                          <hr class="dropdown-divider" />
                        </li>
                        <li>
                          <a class="dropdown-item" href="#">
                            Something else here
                          </a>
                        </li>
                      </ul>
                    </li>
                    <li class="nav-item">
                      <Link
                        className="nav-link text-decoration-none"
                        to="/designer"
                        style={{ color: "#403449" }}
                      >
                        UPCYCLE MARKET
                      </Link>
                    </li>

                    <li class="nav-item">
                      {/* <a
                        class="nav-link"
                        href="#"
                        tabindex="-1"
                        aria-disabled="true"
                        style={{ color: "#403449" }}
                      >
                        FIND A DESIGNER
                      </a> */}

                      <Link
                        className="nav-link text-decoration-none"
                        to="/upcycle"
                        style={{ color: "#403449" }}
                      >
                         FIND A DESIGNER
                      </Link>
                    </li>
                    <li class="nav-item">
                      <a
                        class="nav-link"
                        href="#"
                        tabindex="-1"
                        aria-disabled="true"
                        style={{ color: "#403449" }}
                      >
                        BRAND SUPPORT
                      </a>
                    </li>

                    <li class="nav-item">
                      {/* <a
                        class="nav-link"
                        href="#"
                        tabindex="-1"
                        aria-disabled="true"
                        style={{ color: "#403449" }}
                      >
                        PUBLICATIONS
                      </a> */}
                      <Link
                        className="nav-link text-decoration-none"
                        to="/publication"
                        style={{ color: "#403449" }}
                      >
                          PUBLICATIONS
                      </Link>
                    </li>

                    <li class="nav-item">
                      <a
                        class="nav-link"
                        href="#"
                        tabindex="-1"
                        aria-disabled="true"
                        style={{ color: "#403449" }}
                      >
                        ABOUT
                      </a>
                    </li>
                    <li class="nav-item">
                      <a
                        class="nav-link"
                        href="#"
                        tabindex="-1"
                        aria-disabled="true"
                        style={{ color: "#403449" }}
                      >
                        <img src={search} />
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </nav>
          </div>
        </div>
      </div>
    </div>
  );
}
