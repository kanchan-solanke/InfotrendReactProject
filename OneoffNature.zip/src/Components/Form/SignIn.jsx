import React from "react";
import Headers from "../Heading";
import Navbar from "../Navbar";

export default function SignIn() {
  return (
    <div className="sign-in-wrapper ">
      <div className="d-flex justify-content-end bg-white">
        <Headers />
      </div>
      <div className="pt-2 bg-white">
        <Navbar />
      </div>

      <div className="container pt-5">
        <div className="row">
          <div className="col-md-3"> </div>
          <div className="col-md-6">
            <div className="border border-2 p-5 bg-white ">
              <div className=" pb-5 row">
                <div className="col">
                  <div>
                    <p className="fs-1 fw-600 pb-4 text-center">Sign In</p>
                  </div>
                  <div>
                    <form className="form-wrapper">
                      <div className="d-flex flex-column gap-1 pb-3 mx-4">
                        <label htmlFor="email" className="form">
                          Email
                        </label>
                        <input
                          type="email"
                          className="form-control email-wrap"
                          id="email"
                          placeholder="Enter email"
                        />
                      </div>

                      <div className="d-flex flex-column gap-1 pb-3 mx-4">
                        <label htmlFor="password" className="form">
                          Password
                        </label>
                        <input
                          type="password"
                          className="form-control email-wrap"
                          id="password"
                          placeholder="Enter Password"
                        />
                        <div className="d-flex justify-content-end forget-wrapper">
                          <a
                            href="#"
                            className="forget-password fw-500 text-decoration-none text-end"
                          >
                            Forget Password?
                          </a>
                        </div>
                      </div>
                      <div className="sign-button flex-column d-flex  justify-content-center">
                        <div className="text-center">
                          <button
                            class="bg-dark btn px-5 py-2 text-white mb-3"
                            type="button"
                          >
                            SIGN IN
                          </button>
                        </div>

                        <div className="sign-up-wrap text-center">
                          <span>
                            New to ONEOFFNATURE? Please
                            <a
                              href="#"
                              className="forget-password-signup ms-1 fw-500 text-decoration-none"
                            >
                              Sign Up
                            </a>
                          </span>
                        </div>
                      </div>
                    </form>
                  </div>
                  <div></div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-3"></div>
        </div>
      </div>
    </div>
  );
}
