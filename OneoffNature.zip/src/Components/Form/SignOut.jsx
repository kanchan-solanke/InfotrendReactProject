import React from "react";
import Headers from "../Heading";
import Navbar from "../Navbar";
import BlackButton from "../BlackButton";

export default function SignOut() {
  return (
    <div className="signout-wrapper">
      <div className="d-flex justify-content-end bg-white">
        <Headers />
      </div>
      <div className="bg-white">
        <Navbar />
      </div>

      <div className="pt-5 ">
        <div className="">
          <div className="row">
            <div className="col-12">
              <div>
                <div className="container signup-container bg-white">
                  <div className="signup-container flex-wraps-upcycle">
                    <h4 className="fw-bold fs-1 text-center pt-5">SIGN UP</h4>
                    <h5 className="fw-bold pt-4 pb-4">Personal Information</h5>
                    <form className="form border-bottom-light">
                      <div className="row mb-4">
                        <div className="col">
                          <label htmlFor="firstName" className="form-label">
                            First Name
                          </label>
                          <input
                            type="text"
                            className="form-control input-wrap"
                            id="firstName"
                            placeholder="First Name"
                          />
                        </div>
                        <div className="col">
                          <label htmlFor="lastName" className="form-label">
                            Last Name
                          </label>
                          <input
                            type="text"
                            className="form-control input-wrap"
                            id="lastName"
                            placeholder="Last Name"
                          />
                        </div>
                      </div>
                      <div className="mb-4">
                        <label htmlFor="mobileNumber" className="form-label">
                          Mobile Number
                        </label>
                        <input
                          type="tel"
                          className="form-control"
                          id="mobileNumber"
                          placeholder="Mobile Number"
                        />
                      </div>
                    </form>
                    <h5 className="fw-bold pt-4 pb-4">Sign In Information</h5>
                    <form className="form border-bottom-light">
                      <div className="mb-4">
                        <label htmlFor="EmailId" className="form-label">
                          Email Id
                        </label>
                        <input
                          type="tel"
                          className="form-control"
                          id="EmailId"
                          placeholder="Enter Email ID"
                        />
                      </div>
                      <div className="mb-4">
                        <label htmlFor="Password" className="form-label">
                          Password{" "}
                        </label>
                        <input
                          type="Password"
                          className="form-control"
                          id="Password"
                          placeholder="Enter Password"
                        />
                      </div>
                      <div className="mb-4">
                        <label htmlFor="ConfirmPassword" className="form-label">
                          Confirm Password
                        </label>
                        <input
                          type="tel"
                          className="form-control"
                          id="ConfirmPassword"
                          placeholder="Enter Confirm Password"
                        />
                      </div>
                    </form>
                    <h5 className="fw-bold pt-4 pb-4">Address</h5>
                    <form>
                      <div className="mb-4">
                        <label htmlFor="StreeAddress" className="form-label">
                          Street Address
                        </label>
                        <input
                          type="tel"
                          className="form-control"
                          id="StreeAddress"
                          placeholder="Enter the Street Address"
                        />
                      </div>

                      <div className="row mb-4">
                        <div className="col">
                          <label htmlFor="Country" className="form-label">
                            Country{" "}
                          </label>

                          <ul class="navbar-nav form-control input-wrap">
                            <li class="nav-item dropdown ">
                              <a
                                class="select dropdown-toggle d-flex justify-content-between align-items-center text-decoration-none text-dark px-3"
                                href="#"
                                id="navbarDarkDropdownMenuLink"
                                role="button"
                                data-bs-toggle="dropdown"
                                aria-expanded="false"
                              >
                                Select Country
                              </a>
                              <ul
                                class="dropdown-menu dropdown-menu-dark"
                                aria-labelledby="navbarDarkDropdownMenuLink"
                              >
                                <li>
                                  <a class="dropdown-item" href="#">
                                    Action
                                  </a>
                                </li>
                                <li>
                                  <a class="dropdown-item" href="#">
                                    Another action
                                  </a>
                                </li>
                                <li>
                                  <a class="dropdown-item" href="#">
                                    Something else here
                                  </a>
                                </li>
                              </ul>
                            </li>
                          </ul>
                        </div>

                        <div className="col">
                          <label
                            htmlFor="State/Province"
                            className="form-label"
                          >
                            State/Province
                          </label>
                          <ul class="navbar-nav form-control input-wrap">
                            <li class="nav-item dropdown ">
                              <a
                                className="select dropdown-toggle d-flex justify-content-between align-items-center text-decoration-none px-3 text-dark"
                                href="#"
                                id="navbarDarkDropdownMenuLink"
                                role="button"
                                data-bs-toggle="dropdown"
                                aria-expanded="false"
                              >
                                Select Country
                              </a>
                              <ul
                                class="dropdown-menu dropdown-menu-dark"
                                aria-labelledby="navbarDarkDropdownMenuLink"
                              >
                                <li>
                                  <a
                                    class="dropdown-item text-decoration-none"
                                    href="#"
                                  >
                                    Action
                                  </a>
                                </li>
                                <li>
                                  <a class="dropdown-item" href="#">
                                    Another action
                                  </a>
                                </li>
                                <li>
                                  <a class="dropdown-item" href="#">
                                    Something else here
                                  </a>
                                </li>
                              </ul>
                            </li>
                          </ul>
                        </div>
                      </div>

                      <div className="row mb-4">
                        <div className="col">
                          <label htmlFor="City" className="form-label">
                            City
                          </label>
                          <input
                            type="text"
                            className="form-control input-wrap"
                            id="City"
                            placeholder="Enter City"
                          />
                        </div>

                        <div className="col">
                          <label htmlFor="Postcode" className="form-label">
                            Postcode
                          </label>
                          <input
                            type="text"
                            className="form-control input-wrap"
                            id="Postcode"
                            placeholder=" Enter Postcode"
                          />
                        </div>
                      </div>
                    </form>
                    <div className="form-check container set">
                      <input
                        type="checkbox"
                        className="form-check-input d-flex align-items-center"
                      />
                      <label
                        className="form-check-label default pb-1"
                        htmlFor="giftCheck"
                      >
                        Set it as my default address
                      </label>
                    </div>
                    <div className="save-continue d-flex justify-content-center align-items-center pt-4 pb-2">
                      <BlackButton buttonText="SIGN UP" />
                    </div>
                    <div className="account-wrap d-flex align-items-center justify-content-center">
                      <span>
                        Already have account? Please{" "}
                        <a href="#" className="text-decoration-none text-blue">
                          Sign In
                        </a>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
