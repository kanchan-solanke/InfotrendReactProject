import React from "react";
import Navbar from "./Navbar";
import Sidebar from "./Sidebar";
import Footer from "./Footer";
import Headers from "./Heading";
import Heads from "./Heads";
import upcycle1 from "../assets/upcycle1.png";
import upcycle2 from "../assets/upcycle2.png";
import upcycle3 from "../assets/upcycle3.png";
import upcycle4 from "../assets/upcycle4.png";
import upcycle5 from "../assets/upcycle5.png";
import upcycle6 from "../assets/upcycle6.png";
import upcycle7 from "../assets/upcycle7.png";
import { RxCross2 } from "react-icons/rx";
import uflex1 from "../assets/uflex1.png";
import uflex2 from "../assets/uflex2.png";
import uflex3 from "../assets/uflex3.png";
import uflex4 from "../assets/uflex4.png";
import pound from "../assets/pound.png";
import sustain from "../assets/Sustainable.svg";
import organic from "../assets/Organic.svg";
import recycle from "../assets/Recycled.svg";
import reconstruct from "../assets/reconstruct.svg";
import add from "../assets/add.svg";
export default function Shop() {
  return (
    <div className="upcycle-wrapper">
      <div>
        <Sidebar />
        <div className="d-flex bg-white justify-content-end">
          <Headers />
        </div>
        <div className="container-fluid p-0">
          <div className="bg-white">
            <Navbar />
          </div>

          <section className="bg-primary px-3 py-3">
            <div className="row">
              <div className="col-12">
                <div className="container mission-inner-wrapper p-0">
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item ps-2">
                        <a
                          href="#"
                          className="text-decoration-none text-secondary fs-8"
                        >
                          HOME
                        </a>
                      </li>

                      <li
                        className="breadcrumb-item active text-dark fw-600"
                        aria-current="page"
                      >
                        SHOP
                      </li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </section>

          <section>
            <div className="position-relative z-0">
              <div className="blue-background"></div>
              <div>
                <div className=" upcycle-wraps z-4 position-absolute">
                  <Heads title="SHOP BY" className="fs-42 fw-bold pb-3 px-2" />

                  <div className="row m-0">
                    <div className="col p-0 px-2">
                      <div
                        className="card p-2"
                        style={{ width: "272px", height: "251px" }}
                      >
                        <div className="text-center">
                          <img
                            src={sustain}
                            className="card-img-topd img-fluid"
                            alt="Card Image"
                          />
                        </div>

                        <div className="card-body p-0">
                          <p className="card-text text-nowrap p-1 fs-14 text-center">
                            Manmade Synthesised Materials
                          </p>
                        </div>
                        <div className="card-footer bg-white">
                          <small className="text-muted d-flex justify-content-between">
                            <div>Sustainable</div>
                            <div>
                              <img src={add} alt="" />
                            </div>
                          </small>
                        </div>
                      </div>
                    </div>

                    <div className="col p-0 px-2">
                      <div
                        className="card p-2"
                        style={{ width: "272px", height: "251px" }}
                      >
                        <div className="text-center">
                          <img
                            src={organic}
                            className="card-img-topd img-fluid"
                            alt="Card Image"
                          />
                        </div>

                        <div className="card-body p-0">
                          <p className="card-text text-nowrap p-1 fs-14 text-center">
                            Made of Natural Fribres
                          </p>
                        </div>
                        <div className="card-footer bg-white">
                          <small className="text-muted d-flex justify-content-between">
                            <div>Organic</div>
                            <div>
                              <img src={add} alt="" />
                            </div>
                          </small>
                        </div>
                      </div>
                    </div>

                    <div className="col p-0 px-2">
                      <div
                        className="card p-2"
                        style={{ width: "272px", height: "251px" }}
                      >
                        <div className="text-center">
                          <img
                            src={recycle}
                            className="card-img-topd img-fluid"
                            alt="Card Image"
                          />
                        </div>

                        <div className="card-body p-0">
                          <p className="card-text text-nowrap p-1 fs-14 text-center">
                            Regenerated and Reused
                          </p>
                        </div>
                        <div className="card-footer bg-white">
                          <small className="text-muted d-flex justify-content-between">
                            <div>Recycled</div>
                            <div>
                              <img src={add} alt="" />
                            </div>
                          </small>
                        </div>
                      </div>
                    </div>

                    <div className="col p-0 px-2">
                      <div
                        className="card p-2"
                        style={{ width: "272px", height: "251px" }}
                      >
                        <div className="text-center">
                          <img
                            src={reconstruct}
                            className="card-img-topd img-fluid"
                            alt="Card Image"
                          />
                        </div>

                        <div className="card-body p-0">
                          <p className="card-text text-nowrap p-1 fs-14 text-center">
                            Redesigned into a new garment
                          </p>
                        </div>
                        <div className="card-footer bg-white">
                          <small className="text-muted d-flex justify-content-between">
                            <div>Reconstructed</div>
                            <div>
                              <img src={add} alt="" />
                            </div>
                          </small>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <div className=" pt-5">
            <section className="container pt-5">
              <div className="container">
                <div className="row">
                  <div className="col-2 bg-white p-3">
                    <div className="d-flex justify-content-between pt-3 pb-3 border-bottom">
                      <div>
                        <p>FILTERS</p>
                      </div>
                      <div>
                        <p className="text-warning fw-500">Clear All</p>
                      </div>
                    </div>
                    <div>
                      <ul>
                        <li className="d-flex gap-2 pt-2 pb-2 border-bottom">
                          <input
                            class="form-check-input border-0 bg-dark"
                            type="checkbox"
                            value=""
                            id="flexCheckChecked"
                            checked
                          />
                          <label className="text-nowrap fs-10 fw-500 align-items-center d-flex justify-content-center">
                            Alter & Repairs
                          </label>
                        </li>
                        <li className="d-flex gap-1 pt-2 pb-2 border-bottom">
                          <input
                            class="form-check-input border-0 bg-dark"
                            type="checkbox"
                            value=""
                            id="flexCheckChecked"
                            checked
                          />
                          <label className="text-nowrap fs-10 fw-500 align-items-center d-flex justify-content-center">
                            Knitting & Crocheting
                          </label>
                        </li>
                        <li className="d-flex gap-2 pt-2 pb-2 border-bottom">
                          <input
                            class="form-check-input border-0 bg-dark"
                            type="checkbox"
                            value=""
                            id="flexCheckChecked"
                            checked
                          />
                          <label className="text-nowrap fs-10 fw-500 align-items-center d-flex justify-content-center">
                            Bags & Accessories
                          </label>
                        </li>
                        <li className="d-flex gap-2 pt-2 pb-2 border-bottom">
                          <input
                            class="form-check-input border-0 bg-dark"
                            type="checkbox"
                            value=""
                            id="flexCheckChecked"
                            checked
                          />
                          <label className="text-nowrap fs-10 fw-500 align-items-center d-flex justify-content-center">
                            Make to Measure
                          </label>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div className="col-10 flex-wraps-upcycle ps-4">
                    <div className="d-flex gap-3 align-items-center justify-content-end pt-3 upcycle-dropdown-wrapper">
                      <div className="fw-500">Sort By :</div>
                      <div>
                        <div class="btn-group">
                          <button
                            class="btn bg-white btn-sm dropdown-toggle border border-1 p-2 fw-500"
                            type="button"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                          >
                            Popularity
                          </button>
                          <ul class="dropdown-menu">...</ul>
                        </div>
                      </div>
                    </div>

                    <div className="d-flex gap-3 ps-3">
                      <div className="d-flex border-wraps justify-content-between align-items-center rounded-pill border border-1 px-3 gap-2">
                        <div className="fs-10 ">Reconstruction</div>
                        <div>
                          <RxCross2 />
                        </div>
                      </div>
                      <div className="d-flex border-wraps justify-content-between align-items-center rounded-pill border border-1 px-3 gap-2">
                        <div className="fs-10">Dyes</div>
                        <div>
                          <RxCross2 />
                        </div>
                      </div>
                      <div className="d-flex border-wraps justify-content-between align-items-center rounded-pill border border-1 px-3 gap-2">
                        <div className="fs-10">Alter & Repairs</div>
                        <div>
                          <RxCross2 />
                        </div>
                      </div>
                      <div className="d-flex border-wraps justify-content-between align-items-center rounded-pill border border-1 px-3 gap-2">
                        <div className="fs-10">Bags & Accessories</div>
                        <div>
                          <RxCross2 />
                        </div>
                      </div>
                    </div>
                    <div className="pt-4 container">
                      <div className="row">
                        <div className="col-4">
                          <img
                            src={uflex1}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-4">
                          <img
                            src={uflex2}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-4">
                          <img
                            src={uflex3}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-4">
                          <img
                            src={uflex1}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-4">
                          <img
                            src={uflex4}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-4">
                          <img
                            src={uflex3}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-4">
                          <img
                            src={uflex1}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-4">
                          <img
                            src={uflex4}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-4">
                          <img
                            src={uflex3}
                            alt=""
                            className="img-fluid w-100 pb-2"
                          />
                          <div className="pb-3">
                            <div>Africa Henandez</div>
                            <div className="d-flex justify-content-between">
                              <div>
                                <img src={pound} alt="" />
                                100.00
                              </div>
                              <div>
                                <a
                                  href="#"
                                  className="text-decoration-none fw-500"
                                >
                                  {" "}
                                  Services{" "}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="d-flex justify-content-center pt-5 pb-5">
                <button
                  type="button"
                  class="btn mb-5 border-2 border px-4 py-2 fw-600"
                >
                  VIEW MORE
                </button>
              </div>
            </section>
          </div>

          <div>
            <Footer />
          </div>
        </div>
      </div>
    </div>
  );
}
